-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2025 at 02:17 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'Admin$123');

-- --------------------------------------------------------

--
-- Table structure for table `donor`
--

CREATE TABLE `donor` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `dob` date DEFAULT NULL,
  `gender` varchar(10) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text NOT NULL,
  `blood_group` varchar(5) DEFAULT NULL,
  `organs` varchar(255) NOT NULL,
  `emergency_contact_name` varchar(100) NOT NULL,
  `emergency_contact_phone` varchar(15) NOT NULL,
  `consent` tinyint(1) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donor`
--

INSERT INTO `donor` (`id`, `full_name`, `dob`, `gender`, `phone`, `email`, `address`, `blood_group`, `organs`, `emergency_contact_name`, `emergency_contact_phone`, `consent`, `password`, `status`) VALUES
(8, 'Dhanushsri', '2004-01-30', 'Female', '9789945782', 'dhanushsriprabhakaran@gmail.com', 'Amman kovil street, Keelaiyur', 'O+', 'Corneas', 'Prabhakaran', '9876543210', 1, '$2y$10$zet1dKRDZledRjVmQQaLRe.lCmZyctnklNC/eQscfQESGhVxuzkV.', 'pending'),
(9, 'Tanya', '2003-08-04', 'Female', '9575867986', 'tanya@gmail.com', 'Madurai', 'AB+', 'Pancreas', 'Ravindran', '9095568432', 1, '$2y$10$7TLrLBtvHEqC9yfNDJgPN.IKoKJAU7/Vqqxz6g5GLVA4gzscOITZe', ''),
(14, 'Rakshan', '2000-07-29', 'Male', '8241352666', 'rakshan@gmail.com', 'Dindigul', 'O+', 'Pancreas', 'Amirtha', '9908823635', 1, '$2y$10$.sAiHpAF/YTZZTNyZ64NZOuHvFsMnGK6Xu34oxvyHxRuMmuLkW8T.', 'approved'),
(15, 'Rithika', '1992-02-21', 'Female', '9898080787', 'rithika@gmail.com', 'Coimbatore', 'B-', 'Kidney', 'Kathir', '7899976567', 1, '$2y$10$HvXp9aEsrlQz4J/5ntNq9e29/ehasuU./aQRkEFtiCKkFROtfX/ai', 'approved'),
(16, 'Ashifa Thilfar', '1996-12-03', 'Female', '08234156782', 'ashifa@gmail.com', 'Sivaganga', 'B+', 'Liver', 'Yusuf Khan', '8906745388', 1, '$2y$10$FWNvrXQDnitJZYv0.EHalOmIYQ7F3KSnOqM18HEPr7yGKfu8fOCZy', 'approved'),
(17, 'Farhana', '1996-06-01', 'Female', '9099076566', 'farhana@gmail.com', 'Theni', 'O+', 'Corneas', 'Shahul Hameed', '8898787657', 1, '$2y$10$bD6skZhCSql/ZFw51TmbJ.fJ5NRnksZdxJsBxUNxwknA0qhPVXT6C', 'approved'),
(18, 'Aabhiya', '1998-04-03', 'Female', '8879867667', 'aabhiya@gmail.com', 'Silaiman', 'AB+', 'Pancreas', 'Chella Ponnu', '9098897878', 1, '$2y$10$RU3yiXYdnsqWfk8y75jcAuJT/nuM.NK6bFMxwmJzmJy21w/gR/CTK', 'approved'),
(19, 'Rizwan', '1996-08-03', 'Male', '9009076565', 'rizwan@gmail.com', 'Sivaganga', 'B-', 'Kidney', 'Fathima', '9098897889', 1, '$2y$10$w27EieMhN3G2bvQDHfXtSeibVvPvuc1WMtYz6Y0Ghm1dkZU3a5K4i', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `event_date` date NOT NULL,
  `location` varchar(255) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `event_name`, `event_date`, `location`, `description`) VALUES
(9, 'Health Awareness Camp', '2025-04-10', 'Community Health Center, Coimbatore', 'A community outreach program aimed at educating the public about maintaining a healthy lifestyle, preventive healthcare measures, and early disease detection. Includes free medical check-ups, health talks, and health resources.'),
(10, 'Blood Donation Drive', '2025-04-15', 'City Hall, Coimbatore', 'An organized event to collect blood donations for hospitals and blood banks. Participants contribute to saving lives through this noble cause.'),
(11, 'Organ Donation Awareness Seminar', '2025-04-20', 'Hotel Grand, Chennai', 'A seminar that educates participants about the significance, process, and impact of organ donation. Features keynote speeches and donor testimonies.'),
(12, 'Volunteer Training Workshop', '2025-04-25', 'Training Hall, Madurai', 'A workshop designed to train volunteers on effective community engagement, event organization, and spreading healthcare awareness.'),
(13, 'Charity Fun Run', '2025-05-02', 'Marina Beach Promenade, Chennai', 'A fun run event to promote fitness while raising funds for healthcare projects. Includes different categories for participants, from beginners to seasoned runners, and ends with a wellness expo.');

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE `hospital` (
  `id` int(11) NOT NULL,
  `hospital_name` varchar(255) NOT NULL,
  `contact_person` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`id`, `hospital_name`, `contact_person`, `email`, `phone`, `address`, `password`, `created_at`, `status`) VALUES
(7, 'Apollo Hospital', 'Dr.Abimanyu', 'apollo@gmail.com', '9078667787', 'Madurai', '$2y$10$lv3PFeUy4YBlenBWaEwopOgflvCfX8WnUbMnWckErOziJ2xswYVuK', '2025-04-01 18:49:37', 'approved'),
(9, 'Wellness Hospital', 'Dr.Ishitha', 'wellness@gmail.com', '9088990990', 'Madurai', '$2y$10$eitIBtLBWIc1nEPI5pzROOsjl0Et6T4zjHKnRS/o5pmk.4fyQvE/K', '2025-04-01 18:56:09', 'approved'),
(10, 'Fortune Hospital', 'Dr.Mithun', 'fortune@gmail.com', '8745632411', 'Theni', '$2y$10$ZO61wyBt5Dv0Rt2AygIi7eYzHP/XnzvsBHLjo6BiqX58eym0ry7By', '2025-04-01 18:58:35', 'approved'),
(12, 'Meenakshi Mission', 'Dr.Yuva', 'nethashri09@gmail.com', '8745632412', 'Madurai', '$2y$10$wB7MqGNf.rl1owwwetg0nubkTwATiSwqRIkhLG/5loLqFbj9Sqipq', '2025-04-03 05:14:22', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `title`, `message`, `created_at`) VALUES
(1, 'Volunteers Needed for Community Health Fair', 'We are in need of volunteers for the upcoming Community Health Fair on April 5th. If you are interested in making a difference, please sign up on our website or contact us directly. Your support is greatly appreciated!\r\n\r\n', '2025-02-23 20:22:54'),
(2, 'Organ Matching Awareness Week', 'Join us for Organ Matching Awareness Week starting May 1st. Learn about the importance of organ donation and how you can help. Educational sessions and activities will be held throughout the week. Let\'s make a difference together!\r\n\r\n', '2025-02-23 20:27:42');

-- --------------------------------------------------------

--
-- Table structure for table `organ_requests`
--

CREATE TABLE `organ_requests` (
  `id` int(11) NOT NULL,
  `hospital_name` varchar(255) NOT NULL,
  `organ_requested` varchar(255) NOT NULL,
  `urgency` varchar(50) NOT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `donor_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `organ_requests`
--

INSERT INTO `organ_requests` (`id`, `hospital_name`, `organ_requested`, `urgency`, `status`, `donor_id`) VALUES
(10, 'Fortune Hospital', 'Kidney', 'High', 'Pending', 10),
(11, 'Fortune Hospital', ' Lungs', 'Medium', 'Pending', 8),
(14, 'Fortune Hospital', 'Corneas', 'High', 'Pending', 8),
(15, 'Fortune Hospital', 'Kidney', 'High', '', 9),
(16, 'Fortune Hospital', 'Liver', 'Medium', 'Pending', 12),
(17, 'Fortune Hospital', 'Pancreas', 'Medium', 'Rejected', 14),
(18, 'Fortune Hospital', 'Liver', 'Medium', '', 16),
(19, 'Fortune Hospital', 'Kidney', 'High', 'Rejected', 15),
(20, 'Wellness Hospital', 'Pancreas', 'High', 'Pending', 9),
(21, 'Wellness Hospital', 'Kidney', 'High', 'Pending', 15);

-- --------------------------------------------------------

--
-- Table structure for table `participation`
--

CREATE TABLE `participation` (
  `id` int(11) NOT NULL,
  `volunteer_name` varchar(255) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `participation`
--

INSERT INTO `participation` (`id`, `volunteer_name`, `event_name`, `email`, `phone_number`) VALUES
(1, 'Nirmala', 'Health Awareness Camp', 'nirmala@gmail.com', '8906745345'),
(2, 'Dhanushsri Prabhakaran', 'Charity Fun Run', 'dhanushsriprabhakaran4@gmail.com', '8098035474'),
(4, 'Dr.Abimanyu', 'Blood Donation Drive', 'apollo@gmail.com', '9807987654'),
(8, 'Ashifa', 'Organ Donation Awareness Seminar', 'ashifa@gmail.com', '9564738290'),
(10, 'Nirmala', 'Organ Donation Awareness Seminar', 'nirmala@gmail.com', '8906745345');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `age` int(11) NOT NULL,
  `blood_type` varchar(3) NOT NULL,
  `organ_needed` varchar(50) NOT NULL,
  `status` varchar(50) DEFAULT 'waiting',
  `hospital_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `name`, `age`, `blood_type`, `organ_needed`, `status`, `hospital_id`) VALUES
(1, 'Nithya', 24, 'A+', 'Heart', 'waiting', NULL),
(6, 'Reena', 43, 'AB-', 'Lungs', 'waiting', NULL),
(7, 'Ram', 54, 'O+', 'Liver', 'waiting', NULL),
(8, 'Lekha', 30, 'O+', 'Kidney', 'waiting', NULL),
(9, 'Samyuktha', 38, 'AB+', 'Pancreas', 'waiting', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pledges`
--

CREATE TABLE `pledges` (
  `id` int(11) NOT NULL,
  `volunteer_id` int(11) NOT NULL,
  `pledge_name` varchar(255) NOT NULL,
  `pledge_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pledges`
--

INSERT INTO `pledges` (`id`, `volunteer_id`, `pledge_name`, `pledge_date`) VALUES
(4, 45, 'Dhanushsri Prabhakaran', '2025-03-02');

-- --------------------------------------------------------

--
-- Table structure for table `volunteer`
--

CREATE TABLE `volunteer` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `dob` date DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `blood_group` varchar(5) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `time_of_contribution` varchar(50) DEFAULT NULL,
  `area_of_interest` text DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `volunteer`
--

INSERT INTO `volunteer` (`id`, `full_name`, `dob`, `email`, `address`, `phone`, `blood_group`, `gender`, `time_of_contribution`, `area_of_interest`, `photo`, `password`, `status`) VALUES
(41, 'Fernandez', '1996-08-29', 'fernand@gmail.com', 'Chennai', '9876543210', 'AB+', 'Female', 'Part Time', 'Content Writing', 'uploads/person1.jpg', '$2y$10$CSTlL0PJZ3ipyur9yNylHO1iAjurouJYV0K.UC1ocIJ1q4PA97vF.', 'approved'),
(45, 'Rahima', '1999-07-05', 'radh@gmail.com', 'Madurai', '7838783123', 'B+', 'Female', 'Part Time', 'Content Writing', 'uploads/lady2.jpg', '$2y$10$BmUr6T3QZ.ry/eOdL9JXYOaOEZZmMeG3oIgoE.Piolvx4GdARjimq', 'pending'),
(47, 'Nirmala', '2002-07-29', 'nirmala@gmail.com', 'Sivaganga', '8098035472', 'B+', 'Female', 'Part Time', 'Outreach Programs', 'uploads/lady1.jpg', '$2y$10$TIWG6.uYjGphHaPmMzbcku6UjBxaxpIyYOzfYT09rs/UcwcfYGrny', 'approved'),
(48, 'Kiran', '1999-02-01', 'kiran@gmail.com', 'Sivaganga', '9099076577', 'O+', 'Male', 'Part Time', 'Outreach Programs', 'uploads/person1.jpg', '$2y$10$10Jem37wo91G7fAVatpwo.N4tG/MJeKqImhdME5.QhzLFsjIUWEKO', 'approved');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donor`
--
ALTER TABLE `donor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hospital`
--
ALTER TABLE `hospital`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `organ_requests`
--
ALTER TABLE `organ_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `participation`
--
ALTER TABLE `participation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pledges`
--
ALTER TABLE `pledges`
  ADD PRIMARY KEY (`id`),
  ADD KEY `volunteer_id` (`volunteer_id`);

--
-- Indexes for table `volunteer`
--
ALTER TABLE `volunteer`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `donor`
--
ALTER TABLE `donor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `hospital`
--
ALTER TABLE `hospital`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `organ_requests`
--
ALTER TABLE `organ_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `participation`
--
ALTER TABLE `participation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `pledges`
--
ALTER TABLE `pledges`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `volunteer`
--
ALTER TABLE `volunteer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pledges`
--
ALTER TABLE `pledges`
  ADD CONSTRAINT `pledges_ibfk_1` FOREIGN KEY (`volunteer_id`) REFERENCES `volunteer` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
