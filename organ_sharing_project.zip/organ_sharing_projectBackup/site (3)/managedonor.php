<?php
session_start();
include 'db_connection.php';

$search_query = '';
if (isset($_POST['search'])) {
    $search_query = $_POST['search_query'];
}

try {
    $donors = [];
    $stmt = $conn->prepare("SELECT id, full_name, dob, gender, phone, email, address, blood_group, organs, emergency_contact_name, emergency_contact_phone FROM donor WHERE full_name LIKE ?");
    $search_param = "%" . $search_query . "%";
    $stmt->bind_param("s", $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $donors[] = $row;
        }
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Donors</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <div class="container-fluid">
            <a class="navbar-brand" href="d1.php">Admin Dashboard</a>
            <a href="d1.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>

        <h3>Manage Donors</h3>
        
        <!-- Search Form -->
        <form method="post" class="mb-3">
            <div class="input-group">
                <input type="text" name="search_query" class="form-control" placeholder="Search for a donor" value="<?php echo htmlspecialchars($search_query); ?>">
                <button type="submit" name="search" class="btn btn-primary"><i class="fas fa-search"></i> Search</button>
            </div>
        </form>
        
        <a href="add_donor.php" class="btn btn-primary mb-3"><i class="fas fa-plus"></i> Add Donor</a>
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>Date of Birth</th>
                    <th>Gender</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Blood Group</th>
                    <th>Organs</th>
                    <th>Emergency Contact Name</th>
                    <th>Emergency Contact Phone</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($donors) > 0): ?>
                    <?php foreach ($donors as $donor): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($donor['id']); ?></td>
                            <td><?php echo htmlspecialchars($donor['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($donor['dob']); ?></td>
                            <td><?php echo htmlspecialchars($donor['gender']); ?></td>
                            <td><?php echo htmlspecialchars($donor['phone']); ?></td>
                            <td><?php echo htmlspecialchars($donor['email']); ?></td>
                            <td><?php echo htmlspecialchars($donor['address']); ?></td>
                            <td><?php echo htmlspecialchars($donor['blood_group']); ?></td>
                            <td><?php echo htmlspecialchars($donor['organs']); ?></td>
                            <td><?php echo htmlspecialchars($donor['emergency_contact_name']); ?></td>
                            <td><?php echo htmlspecialchars($donor['emergency_contact_phone']); ?></td>
                            <td>
                                <button class="btn btn-warning btn-sm edit-btn" data-id="<?php echo $donor['id']; ?>" data-name="<?php echo $donor['full_name']; ?>" data-dob="<?php echo $donor['dob']; ?>" data-gender="<?php echo $donor['gender']; ?>" data-phone="<?php echo $donor['phone']; ?>" data-email="<?php echo $donor['email']; ?>" data-address="<?php echo $donor['address']; ?>" data-blood="<?php echo $donor['blood_group']; ?>" data-organs="<?php echo $donor['organs']; ?>" data-emergency-name="<?php echo $donor['emergency_contact_name']; ?>" data-emergency-phone="<?php echo $donor['emergency_contact_phone']; ?>"><i class="fas fa-edit"></i> Edit</button>
                                <a href="delete_donor.php?id=<?php echo $donor['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');"><i class="fas fa-trash"></i> Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="12" class="text-center">No donors found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Edit Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit Donor</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editForm" action="update_donor.php" method="POST">
                        <input type="hidden" id="edit_id" name="id">
                        <div class="mb-3">
                            <label for="edit_name" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="edit_name" name="full_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_dob" class="form-label">Date of Birth</label>
                            <input type="date" class="form-control" id="edit_dob" name="dob" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_gender" class="form-label">Gender</label>
                            <select class="form-control" id="edit_gender" name="gender" required>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="edit_phone" class="form-label">Phone</label>
                            <input type="tel" class="form-control" id="edit_phone" name="phone" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="edit_email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_address" class="form-label">Address</label>
                            <textarea class="form-control" id="edit_address" name="address" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="edit_blood" class="form-label">Blood Group</label>
                            <select class="form-control" id="edit_blood" name="blood_group" required>
                                <option value="A+">A+</option>
                                <option value="B+">B+</option>
                                <option value="O+">O+</option>
                                <option value="AB+">AB+</option>
                                <option value="A-">A-</option>
                                <option value="B-">B-</option>
                                <option value="O-">O-</option>
                                <option value="AB-">AB-</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="edit_organs" class="form-label">Preferred Organs for Donation</label>
                            <textarea class="form-control" id="edit_organs" name="organs" required></textarea>
                        </div>
                        <div class="mb-3">
                                                    <label for="edit_emergency_name" class="form-label">Emergency Contact Name</label>
                        <input type="text" class="form-control" id="edit_emergency_name" name="emergency_contact_name" required>
                    </div>
                        <div class="mb-3">
                            <label for="edit_emergency_phone" class="form-label">Emergency Contact Phone</label>
                            <input type="tel" class="form-control" id="edit_emergency_phone" name="emergency_contact_phone" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('.edit-btn').click(function() {
                $('#edit_id').val($(this).data('id'));
                $('#edit_name').val($(this).data('name'));
                $('#edit_dob').val($(this).data('dob'));
                $('#edit_gender').val($(this).data('gender'));
                $('#edit_phone').val($(this).data('phone'));
                $('#edit_email').val($(this).data('email'));
                $('#edit_address').val($(this).data('address'));
                $('#edit_blood').val($(this).data('blood'));
                $('#edit_organs').val($(this).data('organs'));
                $('#edit_emergency_name').val($(this).data('emergency-name'));
                $('#edit_emergency_phone').val($(this).data('emergency-phone'));
                $('#editModal').modal('show');
            });
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
