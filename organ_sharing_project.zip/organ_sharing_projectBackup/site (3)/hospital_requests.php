<?php
session_start();
include 'db_connection.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer autoload
require 'vendor/autoload.php';

// Ensure the donor is logged in
if (!isset($_SESSION['donor_id'])) {
    header("Location: donorlogin.php");
    exit();
}

$donor_id = $_SESSION['donor_id']; // Retrieve donor ID from the session
$organ_requests = [];
$success_message = "";
$error_message = "";

// Handle accept/reject actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $request_id = $_POST['request_id']; // The ID of the organ request
    $new_status = $_POST['action'] === 'accept' ? 'Accepted' : 'Rejected';

    try {
        // Update the request status in the database
        $stmt = $conn->prepare("UPDATE organ_requests SET status = ? WHERE id = ?");
        if ($stmt === false) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        $stmt->bind_param("si", $new_status, $request_id);
        $stmt->execute();

        // Fetch hospital email and organ details using a JOIN
        $fetch_stmt = $conn->prepare("
            SELECT h.email AS hospital_email, o.organ_requested 
            FROM organ_requests o
            JOIN hospital h ON o.hospital_name = h.hospital_name
            WHERE o.id = ?
        ");
        if ($fetch_stmt === false) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        $fetch_stmt->bind_param("i", $request_id);
        $fetch_stmt->execute();
        $fetch_stmt->bind_result($hospital_email, $organ_requested);
        $fetch_stmt->fetch();
        $fetch_stmt->close();

        // Fetch donor contact details from donor table
        $donor_fetch_stmt = $conn->prepare("
            SELECT email, phone 
            FROM donor 
            WHERE id = ?
        ");
        if ($donor_fetch_stmt === false) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        $donor_fetch_stmt->bind_param("i", $donor_id);
        $donor_fetch_stmt->execute();
        $donor_fetch_stmt->bind_result($donor_email, $donor_phone);
        $donor_fetch_stmt->fetch();
        $donor_fetch_stmt->close();

        // Send email notification to the hospital
        $mail = new PHPMailer(true);
        try {
            // SMTP server configuration
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com'; // Replace with your SMTP provider
            $mail->SMTPAuth = true;
            $mail->Username = 'dhanushsriprabhakaran4@gmail.com'; // Replace with your email
            $mail->Password = 'glyb yrxb mquu flcu'; // Replace with your app password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Email content
            $mail->setFrom('your-email@gmail.com', 'Organ Request System');
            $mail->addAddress($hospital_email); // Hospital's email address
            $mail->Subject = "Organ Request Update";

            // Add donor contact details if the request is accepted
            if ($new_status === 'Accepted') {
                $mail->Body = "Your request for the organ: $organ_requested has been $new_status by the donor.\n\nDonor Contact Details:\nEmail: $donor_email\nPhone: $donor_phone";
            } else {
                $mail->Body = "Your request for the organ: $organ_requested has been $new_status by the donor.";
            }

            // Send email
            $mail->send();
            $success_message = "Request status updated and notification sent successfully.";
        } catch (Exception $e) {
            $error_message = "Request updated but failed to send email: " . $mail->ErrorInfo;
        }

        $stmt->close();
    } catch (Exception $e) {
        $error_message = "Error updating request: " . $e->getMessage();
    }
}

// Fetch organ requests for the logged-in donor
try {
    $stmt = $conn->prepare("SELECT id, hospital_name, organ_requested, urgency, status FROM organ_requests WHERE donor_id = ?");
    if ($stmt === false) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("i", $donor_id);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $organ_requests[] = $row; // Store organ requests
    }

    $stmt->close();
} catch (Exception $e) {
    $error_message = "Error fetching hospital requests: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital Requests</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-dark bg-dark p-3">
    <a class="navbar-brand" href="donordashboard.php">Donor Dashboard</a>
    <a href="donordashboard.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
</nav>

<div class="container mt-4">
    <h3>Hospital Requests for Your Organs</h3>
    <div class="card mt-4">
        <div class="card-body">
            <?php if (!empty($success_message)): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
            <?php elseif (!empty($error_message)): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
            <?php endif; ?>

            <?php if (!empty($organ_requests)): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Hospital Name</th>
                            <th>Organ Requested</th>
                            <th>Urgency</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($organ_requests as $request): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($request['hospital_name']); ?></td>
                                <td><?php echo htmlspecialchars($request['organ_requested']); ?></td>
                                <td><?php echo htmlspecialchars($request['urgency']); ?></td>
                                <td><?php echo htmlspecialchars($request['status']); ?></td>
                                <td>
                                    <?php if ($request['status'] === 'Pending'): ?>
                                        <form method="post" class="d-inline">
                                            <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                                            <button type="submit" name="action" value="accept" class="btn btn-success btn-sm">Accept</button>
                                        </form>
                                        <form method="post" class="d-inline">
                                            <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                                            <button type="submit" name="action" value="reject" class="btn btn-danger btn-sm">Reject</button>
                                        </form>
                                    <?php else: ?>
                                        <span class="badge bg-info"><?php echo htmlspecialchars($request['status']); ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No hospital requests found for your organs.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
