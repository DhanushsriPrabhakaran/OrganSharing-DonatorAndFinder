<?php
session_start();
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $hospital_name = $_POST['hospital_name'];
    $contact_person = $_POST['contact_person'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];

    try {
        $stmt = $conn->prepare("UPDATE hospital SET hospital_name=?, contact_person=?, email=?, phone=?, address=? WHERE id=?");
        $stmt->bind_param("sssssi", $hospital_name, $contact_person, $email, $phone, $address, $id);

        if ($stmt->execute()) {
            $_SESSION['success'] = "Hospital details updated successfully!";
        } else {
            $_SESSION['error'] = "Failed to update hospital details.";
        }

        $stmt->close();
    } catch (Exception $e) {
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }
    
    header("Location: managehospital.php");
    exit();
} else {
    $_SESSION['error'] = "Invalid request!";
    header("Location: managehospital.php");
    exit();
}
?>
