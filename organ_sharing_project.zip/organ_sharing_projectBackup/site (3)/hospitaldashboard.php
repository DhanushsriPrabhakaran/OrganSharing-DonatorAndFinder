<?php
session_start();
include 'db_connection.php'; // Ensure this path is correct

// Check if 'id' is set in the session
if (!isset($_SESSION['id'])) {
    echo "Hospital ID is not set in the session.";
    exit();
}
$hospital_id = $_SESSION['id'];

// Fetch hospital profile details
try {
    $stmt = $conn->prepare("SELECT * FROM hospital WHERE id = ?");
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("i", $hospital_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $row = $result->fetch_assoc()) {
        $hospital_profile = $row;
    } else {
        echo "Error fetching hospital profile: " . $conn->error;
    }
    $stmt->close();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-dark bg-dark p-3">
        <a class="navbar-brand" href="hospitaldashboard.php">Hospital Dashboard</a>
        <button class="btn btn-danger" onclick="confirmLogout()">
            <i class="fas fa-sign-out-alt"></i> Logout
        </button>
    </nav>
<div class="container mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="list-group">
                <a href="#" class="list-group-item list-group-item-action active">Dashboard</a>
                <a href="hospital_update.php" class="list-group-item list-group-item-action">Update Profile</a>
                <a href="manage_patients.php" class="list-group-item list-group-item-action">Manage Patients</a>
                    <a href="request_organ.php" class="list-group-item list-group-item-action">Request Organ</a>
               
                                <a href="hospital_notifications.php" class="list-group-item list-group-item-action">Notifications</a>
                <a href="#" class="list-group-item list-group-item-action" onclick="confirmLogout()">Logout</a>
            </div>
        </div>
        <div class="col-md-9">
            <h3>Welcome to your Hospital Dashboard</h3>
            <div class="card mt-4">
                <div class="card-body">
                    <h4 class="card-title">Profile Details</h4>
                    <div>
                        <p><strong>Name:</strong> <?php echo htmlspecialchars($hospital_profile['hospital_name'] ?? 'N/A'); ?></p>
                        <p><strong>Contact Person:</strong> <?php echo htmlspecialchars($hospital_profile['contact_person'] ?? 'N/A'); ?></p>
                        <p><strong>Email:</strong> <?php echo htmlspecialchars($hospital_profile['email'] ?? 'N/A'); ?></p>
                        <p><strong>Phone:</strong> <?php echo htmlspecialchars($hospital_profile['phone'] ?? 'N/A'); ?></p>
                        <p><strong>Address:</strong> <?php echo htmlspecialchars($hospital_profile['address'] ?? 'N/A'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function confirmLogout() {
        if (confirm("Are you sure you want to log out?")) {
            window.location.href = "home.html"; // Replace with the home page URL
        }
    }
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
