<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* General Styles */
        body {
            margin: 0;
            font-family: 'Roboto', sans-serif;
            background: #CAE7DF;
            color: #333;
        }

        header {
            background-color: #2A3166;
            padding: 20px;
            color: white;
            text-align: center;
        }

        h1 {
            margin: 0;
            font-size: 2rem;
        }

        /* Services Section */
        .services-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            padding: 40px 20px;
        }

        .service-card {
            background-color: #F4ABAA;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            width: 300px;
            text-align: center;
            padding: 20px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .service-card:hover {
             background-color: #EE7879;
            transform: translateY(-5px);
            box-shadow: 0 8px 12px rgba(0, 0, 0, 0.2);
        }

        .service-card i {
            font-size: 3rem;
            color: #2A3166;
            margin-bottom: 15px;
        }

        .service-card h3 {
            margin: 10px 0;
            font-size: 1.5rem;
            color: #333;
        }

        .service-card p {
            font-size: 1rem;
            color: #555;
        }

        /* Footer */
        footer {
            background-color: #2A3166;
            color: white;
            text-align: center;
            padding: 10px 20px;
            position: relative;
        }

        footer a {
            color: #F4ABAA;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <h1>Our Services</h1>
    </header>

    <!-- Services Section -->
    <div class="services-container">
        <div class="service-card">
            <i class="fas fa-hand-holding-heart"></i>
            <h3>Find Organ Donors</h3>
            <p>Search for organ donors efficiently through our platform to help save lives.</p>
        </div>
        <div class="service-card">
            <i class="fas fa-hospital"></i>
            <h3>Hospital Support</h3>
            <p>Partnered with trusted hospitals for a seamless organ donation process.</p>
        </div>
        <div class="service-card">
            <i class="fas fa-user-plus"></i>
            <h3>Donor Registration</h3>
            <p>Register to become a donor and make a difference in someone's life.</p>
        </div>
        <div class="service-card">
            <i class="fas fa-ambulance"></i>
            <h3>Medical Assistance</h3>
            <p>Access emergency medical support to facilitate organ transplants.</p>
        </div>
        <div class="service-card">
            <i class="fas fa-hands-helping"></i>
            <h3>Volunteer Programs</h3>
            <p>Join our outreach programs to raise awareness about organ donation.</p>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 Online Donor and Finder | <a href="samp.php">Back to Homepage</a></p>
    </footer>
</body>
</html>
