<?php
session_start();
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate volunteer credentials
    $stmt = $conn->prepare("SELECT id, email FROM volunteers WHERE email = ?");
    if ($stmt === false) {
        die("Prepare statement failed: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($volunteer_id, $stored_email);
        $stmt->fetch();
        // For now, we're only using email to login. You can extend it to use passwords as well.
        if ($email === $stored_email) {
            // Set volunteer_id in the session
            $_SESSION['volunteer_id'] = $volunteer_id;
            header("Location: pledge.php"); // Redirect to pledge page after login
            exit();
        } else {
            echo "Invalid email.";
        }
    } else {
        echo "Invalid email.";
    }
    $stmt->close();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <form method="POST">
        <div>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit">Login</button>
    </form>
</body>
</html>
