<?php
session_start();
include 'db_connection.php';

// Check if volunteer_id is set in the session
if (!isset($_SESSION['volunteer_id'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

$volunteer_id = $_SESSION['volunteer_id'];

// Handle pledge
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['take_pledge'])) {
    $pledge_name = $_POST['pledge_name'];
    $pledge_date = date("Y-m-d"); // Store the date in a variable

    try {
        // Store pledge information in the database
        $stmt = $conn->prepare("INSERT INTO pledges (volunteer_id, pledge_name, pledge_date) VALUES (?, ?, ?)");
        if ($stmt === false) {
            throw new Exception("Prepare statement failed: " . $conn->error);
        }
        $stmt->bind_param("iss", $volunteer_id, $pledge_name, $pledge_date); // Use the variable here

        if ($stmt->execute()) {
            $_SESSION['success'] = "Thank you for taking the pledge!";
            $_SESSION['pledge_taken'] = true;
            $_SESSION['pledge_name'] = $pledge_name;
        } else {
            $_SESSION['error'] = "Error: " . $stmt->error;
        }
        $stmt->close();
    } catch (Exception $e) {
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }
}

// Check if the volunteer has already taken the pledge
$pledge_taken = false;
try {
    $stmt = $conn->prepare("SELECT pledge_name FROM pledges WHERE volunteer_id = ?");
    if ($stmt === false) {
        throw new Exception("Prepare statement failed: " . $conn->error);
    }
    $stmt->bind_param("i", $volunteer_id);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $pledge_taken = true;
        $stmt->bind_result($pledge_name);
        $stmt->fetch();
        $_SESSION['pledge_name'] = $pledge_name;
    }
    $stmt->close();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volunteer Dashboard - Pledge</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/ajax/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <div class="container-fluid">
            <a class="navbar-brand" href="volunteerdashboard.php">Volunteer Dashboard</a>
            <a href="volunteerdashboard.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php elseif (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>

        <h3>Pledge</h3>
        <?php if ($pledge_taken): ?>
            <p>Thank you for taking the pledge, <?php echo htmlspecialchars($_SESSION['pledge_name']); ?>!</p>
            <a href="download_certificate.php" class="btn btn-primary"><i class="fas fa-download"></i> Download Certificate</a>
        <?php else: ?>
            <p>As a volunteer, I pledge to:</p>
            <ul>
                <li>Dedicate my time and effort to helping those in need.</li>
                <li>Uphold the values of compassion, integrity, and respect in all my actions.</li>
                <li>Strive to make a positive impact in my community through my volunteer work.</li>
                <li>Continually seek to learn and improve my skills to better serve others.</li>
            </ul>
            <p>If you agree with this pledge, please enter your name and click "Take Pledge" to confirm your commitment.</p>
            <form method="POST">
                <div class="mb-3">
                    <label for="pledge_name">Your Name:</label>
                    <input type="text" id="pledge_name" name="pledge_name" class="form-control" required>
                </div>
                <button type="submit" name="take_pledge" class="btn btn-primary">Take Pledge</button>
            </form>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>
