<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Organ Donation System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to bottom right, #ffcccc, #ccffff); /* Light Pink to Light Blue */
            color: #333;
            overflow-x: hidden;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #4b2c5e;
            padding: 20px 30px; /* Increased padding */
            animation: slideIn 1s ease-out;
        }
        .logo-title {
            display: flex;
            align-items: center;
        }
        .header img {
            width: 60px; /* Increased image size */
            height: 60px; /* Increased image size */
            margin-right: 15px; /* Increased margin */
        }
        .header h1 {
            margin: 0;
            color: white;
            font-size: 2.5em; /* Increased font size */
        }
        .nav {
            display: flex;
        }
        .nav a {
            color: white;
            margin-left: 25px; /* Increased margin */
            text-decoration: none;
            font-size: 1.4em; /* Increased font size */
            animation: fadeIn 2s ease-in;
        }
        .container {
            display: flex;
            justify-content: space-around;
            align-items: center;
            height: calc(100vh - 110px); /* Adjusted height based on increased header size */
            padding: 50px;
            animation: zoomIn 1.5s ease-in-out;
        }
        .content {
            width: 45%;
        }
        .content h2 {
            font-size: 2.5em;
            animation: fadeInUp 2s ease-in-out;
        }
        .content p {
            font-size: 1.2em;
            animation: fadeInUp 2.5s ease-in-out;
        }
        .image-placeholder {
            width: 45%;
            height: auto;
            animation: bounceIn 2s ease-in-out;
        }
        .image-placeholder img {
            width: 100%;
            height: auto;
        }
        @keyframes slideIn {
            from { transform: translateX(-100%); }
            to { transform: translateX(0); }
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes zoomIn {
            from { transform: scale(0); }
            to { transform: scale(1); }
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes bounceIn {
            from, 20%, 40%, 60%, 80%, to { animation-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000); }
            0% { opacity: 0; transform: scale3d(.3, .3, .3); }
            20% { transform: scale3d(1.1, 1.1, 1.1); }
            40% { transform: scale3d(.9, .9, .9); }
            60% { opacity: 1; transform: scale3d(1.03, 1.03, 1.03); }
            80% { transform: scale3d(.97, .97, .97); }
            to { opacity: 1; transform: scale3d(1, 1, 1); }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo-title">
            <img src="d.jpg" alt="Logo Placeholder">
            <h1>HEART 2 HEART</h1>
        </div>
        <div class="nav">
            <a href="#">Home</a>
            <a href="#">About</a>
            <a href="#">Services</a>
        </div>
    </div>
    <div class="container">
        <div class="content">
            <h2>Welcome to our Organ Donation Platform</h2>
            <p>This is a platform for patients, donors, and doctors. Explore to learn more.</p>
        </div>
        <div class="image-placeholder">
            <img src="sam.png" alt="Image Placeholder">
        </div>
    </div>
</body>
</html>
