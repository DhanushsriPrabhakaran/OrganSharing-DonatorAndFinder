<?php
session_start();
include 'db_connection.php'; // Ensure this file contains proper database connection details

// Ensure the hospital is logged in
if (!isset($_SESSION['hospital_name'])) {
    header("Location: hospitallogin.php");
    exit();
}

$success_message = "";
$error_message = "";

// Handle organ request submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_organ'])) {
    $donor_id = $_POST['donor_id'];
    $organ_requested = $_POST['organ'];
    $urgency = $_POST['urgency'];
    $hospital_name = $_SESSION['hospital_name'];
    $status = 'Pending';

    try {
        // Check if the request already exists
        $check_stmt = $conn->prepare("SELECT id FROM organ_requests WHERE hospital_name = ? AND donor_id = ? AND organ_requested = ?");
        if ($check_stmt === false) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        $check_stmt->bind_param("sis", $hospital_name, $donor_id, $organ_requested);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();

        if ($check_result->num_rows > 0) {
            $success_message = "Organ request already exists.";
        } else {
            // Insert new organ request
            $insert_stmt = $conn->prepare("INSERT INTO organ_requests (hospital_name, donor_id, organ_requested, urgency, status) VALUES (?, ?, ?, ?, ?)");
            if ($insert_stmt === false) {
                throw new Exception("Prepare failed: " . $conn->error);
            }
            $insert_stmt->bind_param("sisss", $hospital_name, $donor_id, $organ_requested, $urgency, $status);
            $insert_stmt->execute();
            $insert_stmt->close();
            $success_message = "Organ request submitted successfully.";
        }
        $check_stmt->close();
    } catch (Exception $e) {
        $error_message = "Error submitting organ request: " . $e->getMessage();
    }
}

// Fetch the list of available donors
$search = isset($_GET['search']) ? $_GET['search'] : '';

try {
    // Fetch only donors with status "Approved"
    $stmt = $conn->prepare("SELECT * FROM donor WHERE (full_name LIKE ? OR email LIKE ? OR address LIKE ? OR blood_group LIKE ? OR organs LIKE ?) AND status = 'Approved'");
    if ($stmt === false) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    $search_param = '%' . $search . '%';
    $stmt->bind_param("sssss", $search_param, $search_param, $search_param, $search_param, $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
} catch (Exception $e) {
    $error_message = "Error fetching donors: " . $e->getMessage();
}

// Fetch existing requests for the hospital
$existing_requests = [];
try {
    $stmt = $conn->prepare("SELECT donor_id, organ_requested FROM organ_requests WHERE hospital_name = ?");
    if ($stmt === false) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("s", $_SESSION['hospital_name']);
    $stmt->execute();
    $existing_result = $stmt->get_result();
    while ($row = $existing_result->fetch_assoc()) {
        $existing_requests[] = $row;
    }
    $stmt->close();
} catch (Exception $e) {
    $error_message = "Error fetching existing requests: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Organ</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-dark bg-dark p-3">
    <a class="navbar-brand" href="hospitaldashboard.php">Hospital Dashboard</a>
    <a href="hospitaldashboard.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
</nav>

<div class="container mt-4">
    <h3>Available Donors</h3>
    <div class="card mt-4">
        <div class="card-body">
            <?php if (!empty($success_message)): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
            <?php elseif (!empty($error_message)): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
            <?php endif; ?>

            <form method="get" class="d-flex mb-3">
                <input type="text" name="search" class="form-control me-2" placeholder="Search donors" value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit" class="btn btn-primary">Search</button>
                <a href="request_organ.php" class="btn btn-secondary ms-2">Reset</a>
            </form>

            <?php if (isset($result) && $result->num_rows > 0): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Donor ID</th>
                            <th>Full Name</th>
                            <th>Location</th>
                            <th>Blood Group</th>
                            <th>Available Organs</th>
                            <th>Request Organ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['id']); ?></td>
                                <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['address']); ?></td>
                                <td><?php echo htmlspecialchars($row['blood_group']); ?></td>
                                <td><?php echo htmlspecialchars($row['organs']); ?></td>
                                <td>
                                    <?php foreach (explode(',', $row['organs']) as $organ): ?>
                                        <form method="post">
                                            <input type="hidden" name="donor_id" value="<?php echo htmlspecialchars($row['id']); ?>">
                                            <input type="hidden" name="organ" value="<?php echo htmlspecialchars(trim($organ)); ?>">
                                            <select name="urgency" class="form-select mb-2" required>
                                                <option value="High">High</option>
                                                <option value="Medium">Medium</option>
                                                <option value="Low">Low</option>
                                            </select>
                                            <?php
                                            $already_requested = false;
                                            foreach ($existing_requests as $request) {
                                                if ($request['donor_id'] == $row['id'] && $request['organ_requested'] == trim($organ)) {
                                                    $already_requested = true;
                                                    break;
                                                }
                                            }
                                            ?>
                                            <?php if ($already_requested): ?>
                                                <button type="button" class="btn btn-success" disabled>Requested</button>
                                            <?php else: ?>
                                                <button type="submit" name="request_organ" class="btn btn-primary">Request</button>
                                            <?php endif; ?>
                                        </form>
                                    <?php endforeach; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No donors found.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
