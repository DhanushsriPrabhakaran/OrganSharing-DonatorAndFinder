<?php
session_start();
include 'db_connection.php';

// Handle pledge
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['take_pledge'])) {
    $_SESSION['pledge_taken'] = true;
    $_SESSION['pledge_name'] = $_POST['pledge_name'];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volunteer Dashboard - Pledge</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <div class="container-fluid">
            <a class="navbar-brand" href="d1.php">Volunteer Dashboard</a>
            <a href="d1.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php elseif (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>

        <h3>Pledge</h3>
        <?php if ($_SESSION['pledge_taken']): ?>
            <p>Thank you for taking the pledge, <?php echo htmlspecialchars($_SESSION['pledge_name']); ?>!</p>
            <a href="download_certificate.php" class="btn btn-primary"><i class="fas fa-download"></i> Download Certificate</a>
        <?php else: ?>
            <form method="POST">
                <div class="mb-3">
                    <label for="pledge_name">Your Name:</label>
                    <input type="text" id="pledge_name" name="pledge_name" class="form-control" required>
                </div>
                <button type="submit" name="take_pledge" class="btn btn-primary">Take Pledge</button>
            </form>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
