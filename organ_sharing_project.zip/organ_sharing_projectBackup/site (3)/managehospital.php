<?php
session_start();
include 'db_connection.php';

$search_query = '';
if (isset($_POST['search'])) {
    $search_query = $_POST['search_query'];
}

try {
    $hospitals = [];
    $stmt = $conn->prepare("SELECT id, hospital_name, contact_person, email, phone, address FROM hospital WHERE hospital_name LIKE ?");
    $search_param = "%" . $search_query . "%";
    $stmt->bind_param("s", $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $hospitals[] = $row;
        }
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Hospitals</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <div class="container-fluid">
            <a class="navbar-brand" href="d1.php">Admin Dashboard</a>
            <a href="d1.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>

        <h3>Manage Hospitals</h3>
        
        <!-- Search Form -->
        <form method="post" class="mb-3">
            <div class="input-group">
                <input type="text" name="search_query" class="form-control" placeholder="Search for a hospital" value="<?php echo htmlspecialchars($search_query); ?>">
                <button type="submit" name="search" class="btn btn-primary"><i class="fas fa-search"></i> Search</button>
            </div>
        </form>
        
        <a href="add_hospital.php" class="btn btn-primary mb-3"><i class="fas fa-plus"></i> Add Hospital</a>
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Hospital Name</th>
                    <th>Contact Person</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($hospitals) > 0): ?>
                    <?php foreach ($hospitals as $hospital): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($hospital['id']); ?></td>
                            <td><?php echo htmlspecialchars($hospital['hospital_name']); ?></td>
                            <td><?php echo htmlspecialchars($hospital['contact_person']); ?></td>
                            <td><?php echo htmlspecialchars($hospital['email']); ?></td>
                            <td><?php echo htmlspecialchars($hospital['phone']); ?></td>
                            <td><?php echo htmlspecialchars($hospital['address']); ?></td>
                            <td>
                                <button class="btn btn-warning btn-sm edit-btn" data-id="<?php echo $hospital['id']; ?>" data-name="<?php echo $hospital['hospital_name']; ?>" data-contact="<?php echo $hospital['contact_person']; ?>" data-email="<?php echo $hospital['email']; ?>" data-phone="<?php echo $hospital['phone']; ?>" data-address="<?php echo $hospital['address']; ?>"><i class="fas fa-edit"></i> Edit</button>
                                <a href="delete_hospital.php?id=<?php echo $hospital['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');"><i class="fas fa-trash"></i> Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center">No hospitals found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Edit Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit Hospital</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editForm" action="update_hospital.php" method="POST">
                        <input type="hidden" id="edit_id" name="id">
                        <div class="mb-3">
                            <label for="edit_name" class="form-label">Hospital Name</label>
                            <input type="text" class="form-control" id="edit_name" name="hospital_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_contact" class="form-label">Contact Person</label>
                            <input type="text" class="form-control" id="edit_contact" name="contact_person" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="edit_email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_phone" class="form-label">Phone</label>
                            <input type="text" class="form-control" id="edit_phone" name="phone" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_address" class="form-label">Address</label>
                            <textarea class="form-control" id="edit_address" name="address" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('.edit-btn').click(function() {
                $('#edit_id').val($(this).data('id'));
                $('#edit_name').val($(this).data('name'));
                $('#edit_contact').val($(this).data('contact'));
                $('#edit_email').val($(this).data('email'));
                $('#edit_phone').val($(this).data('phone'));
                $('#edit_address').val($(this).data('address'));
                $('#editModal').modal('show');
            });
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
