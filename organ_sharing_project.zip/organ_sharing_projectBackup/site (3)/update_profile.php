<?php
session_start();
include 'db_connection.php';

if (!isset($_SESSION['donor_id'])) {
    header("Location: donorlogin.php");
    exit();
}

$donor_id = $_SESSION['donor_id'];
$error_message = "";
$success_message = "";

// Fetch donor's current profile details
try {
    $stmt = $conn->prepare("SELECT full_name, dob, gender, email, phone FROM donor WHERE id = ?");
    $stmt->bind_param("i", $donor_id);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($full_name, $dob, $gender, $email, $phone);
    if ($stmt->num_rows > 0) {
        $stmt->fetch();
    } else {
        $error_message = "Donor not found!";
    }
    $stmt->close();
} catch (Exception $e) {
    $error_message = "Error fetching donor details: " . $e->getMessage();
}

// Update profile details
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_full_name = trim($_POST['full_name']);
    $new_dob = trim($_POST['dob']);
    $new_gender = trim($_POST['gender']);
    $new_email = trim($_POST['email']);
    $new_phone = trim($_POST['phone']);

    try {
        $stmt = $conn->prepare("UPDATE donor SET full_name = ?, dob = ?, gender = ?, email = ?, phone = ? WHERE id = ?");
        $stmt->bind_param("sssssi", $new_full_name, $new_dob, $new_gender, $new_email, $new_phone, $donor_id);
        if ($stmt->execute()) {
            $success_message = "Profile updated successfully!";
            $full_name = $new_full_name;
            $dob = $new_dob;
            $gender = $new_gender;
            $email = $new_email;
            $phone = $new_phone;
        } else {
            $error_message = "Error updating profile!";
        }
        $stmt->close();
    } catch (Exception $e) {
        $error_message = "Error updating profile: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <a class="navbar-brand" href="donordashboard.php">Donor Dashboard</a>
        <a href="donordashboard.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to dashboard</a>
    </nav>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Update Profile</h4>
                        <?php if ($error_message): ?>
                            <div class="alert alert-danger"><?php echo $error_message; ?></div>
                        <?php endif; ?>
                        <?php if ($success_message): ?>
                            <div class="alert alert-success"><?php echo $success_message; ?></div>
                        <?php endif; ?>
                        <form method="POST" action="">
                            <div class="form-group">
                                <label for="full_name">Name</label>
                                <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo htmlspecialchars($full_name); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="dob">Date of Birth</label>
                                <input type="date" class="form-control" id="dob" name="dob" value="<?php echo htmlspecialchars($dob); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="gender">Gender</label>
                                <select class="form-control" id="gender" name="gender" required>
                                    <option value="Male" <?php echo ($gender == 'Male') ? 'selected' : ''; ?>>Male</option>
                                    <option value="Female" <?php echo ($gender == 'Female') ? 'selected' : ''; ?>>Female</option>
                                    <option value="Other" <?php echo ($gender == 'Other') ? 'selected' : ''; ?>>Other</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="phone">Phone</label>
                                <input type="text" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($phone); ?>" required>
                            </div>
                            <button type="submit" class="btn btn-primary mt-3">Update Profile</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
