<?php
// Include database connection
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $hospital_name = $conn->real_escape_string($_POST['hospital_name']);
    $contact_person = $conn->real_escape_string($_POST['contact_person']);
    $email = $conn->real_escape_string($_POST['email']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $address = $conn->real_escape_string($_POST['address']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Encrypt password

    // SQL query to insert data into the hospital table
    $sql = "INSERT INTO hospital (hospital_name, contact_person, email, phone, address, password) 
            VALUES ('$hospital_name', '$contact_person', '$email', '$phone', '$address', '$password')";

    if ($conn->query($sql) === TRUE) {
        // Success message and redirection
        echo "<script>
                alert('Hospital registered successfully!');
                window.location.href = 'hospitallogin.php';
              </script>";
    } else {
        // Error message
        echo "<p style='color: red;'>Error: " . $conn->error . "</p>";
    }

    // Close connection
    $conn->close();
}
?>
