<?php
session_start();
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $type = $_POST['type'];
    $action = $_POST['action'];

    try {
        if ($action === 'approve') {
            $stmt = $conn->prepare("UPDATE $type SET status = 'approved' WHERE id = ?");
        } else {
            $stmt = $conn->prepare("DELETE FROM $type WHERE id = ?");
        }
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            $_SESSION['success'] = ucfirst($type) . " " . $action . "d successfully!";
        } else {
            $_SESSION['error'] = "Failed to " . $action . " " . $type . ".";
        }

        $stmt->close();
    } catch (Exception $e) {
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }

    header("Location: approve_reject.php");
    exit();
}

// Fetch pending approvals
$pending_approvals = [];
try {
    $tables = ['donor', 'volunteer', 'hospital'];
    foreach ($tables as $table) {
        $result = $conn->query("SELECT * FROM $table WHERE status = 'pending'");
        while ($row = $result->fetch_assoc()) {
            $pending_approvals[$table][] = $row;
        }
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approve/Reject</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <a class="navbar-brand" href="d1.php">Admin Dashboard</a>
        <a href="d1.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </nav>

    <div class="container mt-4">
        <h3>Approve/Reject</h3>
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>

        <?php foreach ($pending_approvals as $type => $records): ?>
            <h4><?php echo ucfirst($type); ?></h4>
            <?php if (count($records) > 0): ?>
                <table class="table table-bordered table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Details</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($records as $record): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($record['id']); ?></td>
                                <td>
                                    <?php foreach ($record as $key => $value): ?>
                                        <?php if ($key != 'id' && $key != 'status'): ?>
                                            <strong><?php echo ucfirst(str_replace('_', ' ', $key)); ?>:</strong> <?php echo htmlspecialchars($value); ?><br>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </td>
                                <td>
                                    <form action="approve_reject.php" method="POST" style="display:inline-block;">
                                        <input type="hidden" name="id" value="<?php echo $record['id']; ?>">
                                        <input type="hidden" name="type" value="<?php echo $type; ?>">
                                        <input type="hidden" name="action" value="approve">
                                        <button type="submit" class="btn btn-success btn-sm">Approve</button>
                                    </form>
                                    <form action="approve_reject.php" method="POST" style="display:inline-block;">
                                        <input type="hidden" name="id" value="<?php echo $record['id']; ?>">
                                        <input type="hidden" name="type" value="<?php echo $type; ?>">
                                        <input type="hidden" name="action" value="reject">
                                        <button type="submit" class="btn btn-danger btn-sm">Reject</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No pending approvals for <?php echo $type; ?>.</p>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>

    <script>
        function confirmLogout() {
            if (confirm("Are you sure you want to log out?")) {
                window.location.href = "home.html"; // Replace with the home page URL
            }
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
