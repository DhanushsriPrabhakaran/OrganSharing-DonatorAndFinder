<?php
session_start();
require_once 'libs/fpdf.php'; // Adjust path as needed

// Check if pledge was taken
if (!isset($_SESSION['pledge_taken']) || !$_SESSION['pledge_taken']) {
    header("Location: pledge.php");
    exit();
}

$pledge_name = $_SESSION['pledge_name'];
$pledge_date = date("F d, Y"); // More readable format

// Create a new PDF document
class PDF extends FPDF
{
    function Header()
    {
        // Add a border
        $this->Rect(5, 5, 200, 287, 'D'); // Outer border
        
        // Add Logo (Ensure 'logo.png' exists or update path)
        if (file_exists('logo.png')) {
            $this->Image('logo.png', 85, 10, 40);
        }
        
        // Set title font
        $this->SetFont('Arial', 'B', 24);
        $this->Ln(30);
        
        // Certificate Title
        $this->Cell(0, 10, 'Certificate of Pledge', 0, 1, 'C');
        
        // Subtitle
        $this->SetFont('Arial', 'I', 14);
        $this->Cell(0, 10, 'Recognizing Dedication and Commitment', 0, 1, 'C');
        $this->Ln(10);
    }

    function Footer()
    {
        $this->SetY(-30);
        $this->SetFont('Arial', 'I', 10);
        $this->Cell(0, 10, 'This certificate is awarded as a token of appreciation.', 0, 1, 'C');
    }

    function AddPledge($name, $date)
    {
        // Add certificate content
        $this->SetFont('Arial', '', 14);
        $this->SetTextColor(50, 60, 100);
        $this->Ln(10);

        // Personalized message
        $this->Cell(0, 10, "This is to certify that", 0, 1, 'C');
        
        // Volunteer Name (Bold & Large)
        $this->SetFont('Arial', 'B', 20);
        $this->Cell(0, 10, strtoupper($name), 0, 1, 'C');
        $this->Ln(5);
        
        // Statement
        $this->SetFont('Arial', '', 14);
        $this->MultiCell(0, 10, "has taken a pledge on {$date} to uphold the values of volunteerism and service. "
            . "This individual is committed to dedicating time, effort, and compassion in making a positive impact "
            . "on society and promoting the spirit of humanity.", 0, 'C');
        $this->Ln(10);

        // Pledge Details
        $this->SetFont('Arial', 'I', 12);
        $this->MultiCell(0, 8, utf8_decode("As a volunteer, I pledge to:\n" .
            "- Dedicate my time and effort to helping those in need.\n" .
            "- Uphold the values of compassion, integrity, and respect.\n" .
            "- Strive to make a positive impact in my community.\n" .
            "- Continually learn and improve to better serve others.\n"), 0, 'L');

        $this->Ln(20);
    }
}

// Start output buffering
ob_start();

// Create and output PDF
$pdf = new PDF();
$pdf->AddPage();
$pdf->AddPledge($pledge_name, $pledge_date);
$pdf->Output('D', 'pledge_certificate.pdf');

// End and flush output buffering
ob_end_flush();
exit();
?>
