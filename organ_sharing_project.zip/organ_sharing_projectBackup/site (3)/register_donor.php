<?php
// Database connection
$host = 'localhost';
$dbname = 'project'; // Database name
$username = 'root';  // Default MySQL username
$password = '';      // Default MySQL password (update if required)

// Connect to the database
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process the form
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $blood_group = $_POST['blood_group']; 
    $address = $_POST['address'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Secure password hashing
    $organs = implode(", ", $_POST['organs']); // Combine selected organs into a string

    // Insert into the database
    $sql = "INSERT INTO donor (full_name, email, phone, blood_group, address, username, password, organs)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssss", $full_name, $email, $phone, $blood_group, $address, $username, $password, $organs);

    if ($stmt->execute()) {
        echo "Registration successful!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
