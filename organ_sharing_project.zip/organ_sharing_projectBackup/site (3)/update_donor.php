<?php
session_start();
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $full_name = $_POST['full_name'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $blood_group = $_POST['blood_group'];
    $organs = $_POST['organs'];
    $emergency_contact_name = $_POST['emergency_contact_name'];
    $emergency_contact_phone = $_POST['emergency_contact_phone'];

    try {
        $stmt = $conn->prepare("UPDATE donor SET full_name=?, dob=?, gender=?, phone=?, email=?, address=?, blood_group=?, organs=?, emergency_contact_name=?, emergency_contact_phone=? WHERE id=?");
        $stmt->bind_param("ssssssssssi", $full_name, $dob, $gender, $phone, $email, $address, $blood_group, $organs, $emergency_contact_name, $emergency_contact_phone, $id);

        if ($stmt->execute()) {
            $_SESSION['success'] = "Donor details updated successfully!";
        } else {
            $_SESSION['error'] = "Failed to update donor details.";
        }

        $stmt->close();
    } catch (Exception $e) {
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }
    
    header("Location: managedonor.php");
    exit();
} else {
    $_SESSION['error'] = "Invalid request!";
    header("Location: managedonor.php");
    exit();
}
?>
