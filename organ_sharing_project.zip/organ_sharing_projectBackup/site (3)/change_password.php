<?php
session_start();
include 'db_connection.php';

if (!isset($_SESSION['donor_id'])) {
    header("Location: donorlogin.php");
    exit();
}

$donor_id = $_SESSION['donor_id'];
$error_message = "";
$success_message = "";

// Update password
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $current_password = trim($_POST['current_password']);
    $new_password = trim($_POST['new_password']);
    $confirm_new_password = trim($_POST['confirm_new_password']);

    if ($new_password !== $confirm_new_password) {
        $error_message = "New passwords do not match!";
    } else {
        try {
            // Fetch the current password from the database
            $stmt = $conn->prepare("SELECT password FROM donor WHERE id = ?");
            $stmt->bind_param("i", $donor_id);
            $stmt->execute();
            $stmt->store_result();
            $stmt->bind_result($hashed_password);
            if ($stmt->num_rows > 0) {
                $stmt->fetch();
                if (password_verify($current_password, $hashed_password)) {
                    // Update the password
                    $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $stmt_update = $conn->prepare("UPDATE donor SET password = ? WHERE id = ?");
                    $stmt_update->bind_param("si", $new_hashed_password, $donor_id);
                    if ($stmt_update->execute()) {
                        $success_message = "Password updated successfully!";
                    } else {
                        $error_message = "Error updating password!";
                    }
                    $stmt_update->close();
                } else {
                    $error_message = "Current password is incorrect!";
                }
            } else {
                $error_message = "Donor not found!";
            }
            $stmt->close();
        } catch (Exception $e) {
            $error_message = "Error updating password: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <a class="navbar-brand" href="donordashboard.php">Donor Dashboard</a>
        <a href="donordashboard.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i>Back to dashboard</a>
    </nav>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Change Password</h4>
                        <?php if ($error_message): ?>
                            <div class="alert alert-danger"><?php echo $error_message; ?></div>
                        <?php endif; ?>
                        <?php if ($success_message): ?>
                            <div class="alert alert-success"><?php echo $success_message; ?></div>
                        <?php endif; ?>
                        <form method="POST" action="">
                            <div class="form-group">
                                <label for="current_password">Current Password</label>
                                <input type="password" class="form-control" id="current_password" name="current_password" required>
                            </div>
                            <div class="form-group">
                                <label for="new_password">New Password</label>
                                <input type="password" class="form-control" id="new_password" name="new_password" required>
                            </div>
                            <div class="form-group">
                                <label for="confirm_new_password">Confirm New Password</label>
                                <input type="password" class="form-control" id="confirm_new_password" name="confirm_new_password" required>
                            </div>
                            <button type="submit" class="btn btn-primary mt-3">Change Password</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
