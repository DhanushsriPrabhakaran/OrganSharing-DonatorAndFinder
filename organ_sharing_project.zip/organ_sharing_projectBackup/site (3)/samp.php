<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Organ Donation System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #CAE7DF; /* Mint green background */
            color: #2A3166; /* Deep blue text */
            overflow-x: hidden;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #2A3166; /* Deep blue header */
            padding: 20px 30px;
            animation: slideIn 1s ease-out;
        }

        .logo-title {
            display: flex;
            align-items: center;
        }

        .header img {
            width: 60px;
            height: 60px;
            margin-right: 15px;
        }

        .header h1 {
            margin: 0;
            color: #F4ABAA; /* Light pink text */
            font-size: 2.5em;
        }

        .nav {
            display: flex;
        }

        .nav a {
            color: #F4ABAA; /* Light pink links */
            margin-left: 25px;
            text-decoration: none;
            font-size: 1.4em;
            animation: fadeIn 2s ease-in;
        }

        .nav a:hover {
            color: #EE7879; /* Soft red hover effect */
        }

        .container {
            display: flex;
            justify-content: space-around;
            align-items: center;
            height: calc(100vh - 110px);
            padding: 50px;
            animation: zoomIn 1.5s ease-in-out;
            flex-wrap: wrap;
        }

        .content {
            width: 45%;
        }

        .content h2 {
            font-size: 2.5em;
            color: #2A3166; /* Deep blue heading */
            animation: fadeInUp 2s ease-in-out;
        }

        .content p {
            font-size: 1.2em;
            color: #2A3166; /* Deep blue text for contrast */
            animation: fadeInUp 2.5s ease-in-out;
        }

        .image-placeholder {
            width: 45%;
            height: auto;
            animation: bounceIn 2s ease-in-out;
        }

        .image-placeholder img {
            width: 100%;
            height: auto;
        }

        #loginRegisterButton {
            background-color: #EE7879; /* Soft red background */
            color: white;
            font-size: 18px;
            font-weight: bold;
            padding: 15px 30px;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease-in-out;
        }

        #loginRegisterButton:hover {
            background-color: #2A3166; /* Deep blue hover effect */
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
            transform: scale(1.05);
        }

        #loginRegisterButton:active {
            background-color: #F4ABAA; /* Light pink active effect */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
            transform: scale(0.98);
        }

        footer {
            background-color: #2A3166; /* Deep blue footer */
            color: #F4ABAA; /* Light pink text */
            text-align: center;
            padding: 20px;
            margin-top: 50px;
            border-radius: 10px;
        }

        footer h5 {
            font-size: 14px;
        }

        /* Animations */
        @keyframes slideIn {
            from { transform: translateX(-100%); }
            to { transform: translateX(0); }
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes zoomIn {
            from { transform: scale(0); }
            to { transform: scale(1); }
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes bounceIn {
            from, 20%, 40%, 60%, 80%, to { animation-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000); }
            0% { opacity: 0; transform: scale3d(.3, .3, .3); }
            20% { transform: scale3d(1.1, 1.1, 1.1); }
            40% { transform: scale3d(.9, .9, .9); }
            60% { opacity: 1; transform: scale3d(1.03, 1.03, 1.03); }
            80% { transform: scale3d(.97, .97, .97); }
            to { opacity: 1; transform: scale3d(1, 1, 1); }
        }

        /* Mobile Responsiveness */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
                padding: 30px;
                height: auto;
            }

            .content, .image-placeholder {
                width: 100%;
                text-align: center;
            }

            .header h1 {
                font-size: 2em;
            }

            .nav a {
                font-size: 1.2em;
                margin-left: 10px;
            }

            .content h2 {
                font-size: 2em;
            }

            .content p {
                font-size: 1.1em;
            }
        }

        @media (max-width: 480px) {
            .header h1 {
                font-size: 1.8em;
            }

            .nav a {
                font-size: 1em;
            }

            .content h2 {
                font-size: 1.8em;
            }

            .content p {
                font-size: 1em;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo-title">
            <img src="d.jpg" alt="Logo Placeholder">
            <h1>HEART 2 HEART</h1>
        </div>
        <div class="nav">
            <a href="#home">Home</a>
            <a href="services.php">Services</a>
            <a href="#about">About</a>
        </div>
    </div>
    <!-- Hero Section -->
    <div class="container" id="home">
        <div class="content">
            <h2>Be the Miracle: Donate or Find Life-Saving Organs Today</h2>
            <p>Whether you're looking to save a life or receive a second chance, we're here to connect heroes with those in need!</p>
            <button 
                onclick="window.location.href='log.php'" 
                id="loginRegisterButton">
                Login/Register Here
            </button>
        </div>
        <div class="image-placeholder">
            <img src="giphy.gif" alt="Organ Image">
        </div>
    </div>
    <!-- Footer -->
    <footer>
        <h5>Together, We Save Lives. Whether you're giving or receiving, your choice matters. Join us today.</h5>
    </footer>
</body>
</html>
