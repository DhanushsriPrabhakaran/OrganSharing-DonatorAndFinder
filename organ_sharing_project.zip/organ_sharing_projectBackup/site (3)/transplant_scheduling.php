<?php
session_start();
include 'db_connection.php'; // Ensure this path is correct

$success_message = "";

// Handle Transplant Scheduling form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['schedule_transplant'])) {
    list($patient_id, $donor_id) = explode(',', $_POST['match']);
    $organ = $_POST['organ'];
    $transplant_date = $_POST['transplant_date'];
    $hospital_id = $_SESSION['id']; // Assuming hospital ID is stored in session
    $status = 'scheduled'; // Initial status for new requests

    try {
        $stmt = $conn->prepare("INSERT INTO transplant_schedule (patient_id, donor_id, transplant_date, status, organ, hospital_id) VALUES (?, ?, ?, ?, ?, ?)");
        if ($stmt === false) {
            die("Prepare failed: " . $conn->error);
        }
        $stmt->bind_param("iisssi", $patient_id, $donor_id, $transplant_date, $status, $organ, $hospital_id);
        $stmt->execute();
        $stmt->close();

        $_SESSION['success'] = "Transplant scheduled successfully.";
    } catch (Exception $e) {
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }

    header("Location: transplant_scheduling.php");
    exit();
}

// Fetch matched patients and donors from organ_matching table
$matches = [];
$result = $conn->query("SELECT om.patient_id, om.donor_id, p.name AS patient_name, d.full_name AS donor_name, om.organ_type 
                        FROM organ_matching om 
                        JOIN patients p ON om.patient_id = p.id 
                        JOIN donor d ON om.donor_id = d.id 
                        WHERE om.status = 'matched'");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $matches[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transplant Scheduling</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function updateOrganField() {
            var matchSelect = document.getElementById('match');
            var selectedOption = matchSelect.options[matchSelect.selectedIndex];
            var organ = selectedOption.getAttribute('data-organ');
            document.getElementById('organ').value = organ;
        }
        
        function changeButtonText() {
            var button = document.querySelector('button[name="schedule_transplant"]');
            button.textContent = 'Scheduled';
            button.disabled = true; // Optional: Disable the button after scheduling
        }
    </script>
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <a class="navbar-brand" href="dashboard.php">Hospital Dashboard</a>
        <a href="hospitaldashboard.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </nav>

    <div class="container mt-4">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div> 
        <?php endif; ?>
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <h3>Schedule a Transplant</h3>
        <form method="post" action="transplant_scheduling.php" onsubmit="changeButtonText()">
            <div class="mb-3">
                <label for="match" class="form-label">Select Patient and Donor Match</label>
                <select class="form-control" id="match" name="match" onchange="updateOrganField()" required>
                    <option value="" disabled selected>Select a match</option>
                    <?php foreach ($matches as $match): ?>
                        <option value="<?php echo $match['patient_id'] . ',' . $match['donor_id']; ?>" data-organ="<?php echo htmlspecialchars($match['organ_type']); ?>">
                            Patient: <?php echo htmlspecialchars($match['patient_name']); ?> (<?php echo htmlspecialchars($match['organ_type']); ?>) - Donor: <?php echo htmlspecialchars($match['donor_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="transplant_date" class="form-label">Transplant Date & Time</label>
                <input type="datetime-local" class="form-control" id="transplant_date" name="transplant_date" required>
            </div>
            <div class="mb-3">
                <label for="organ" class="form-label">Organ</label>
                <input type="text" class="form-control" id="organ" name="organ" readonly>
            </div>
            <button type="submit" name="schedule_transplant" class="btn btn-primary">Schedule Transplant</button>
        </form>
    </div>
</body>
</html>
