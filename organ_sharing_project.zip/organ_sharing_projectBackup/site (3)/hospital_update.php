<?php
session_start();
include 'db_connection.php'; // Ensure this path is correct

// Check if 'id' is set in the session
if (!isset($_SESSION['id'])) {
    echo "Hospital ID is not set in the session.";
    exit();
}
$hospital_id = $_SESSION['id'];

$hospital_profile = [];

// Fetch hospital profile details
try {
    $stmt = $conn->prepare("SELECT * FROM hospital WHERE id = ?");
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("i", $hospital_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $row = $result->fetch_assoc()) {
        $hospital_profile = $row;
    } else {
        echo "Error fetching hospital profile: " . $conn->error;
    }
    $stmt->close();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $hospital_name = $_POST['hospital_name'];
    $contact_person = $_POST['contact_person'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $new_password = $_POST['new_password'];

    // Update hospital profile details
    try {
        // Check if new password is provided
        if (!empty($new_password)) {
            // Hash the new password before storing it
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare("UPDATE hospital SET hospital_name = ?, contact_person = ?, email = ?, phone = ?, address = ?, password = ? WHERE id = ?");
            if ($stmt === false) {
                die("Prepare failed: " . $conn->error);
            }
            $stmt->bind_param("sssssii", $hospital_name, $contact_person, $email, $phone, $address, $hashed_password, $hospital_id);
        } else {
            // Update profile without changing the password
            $stmt = $conn->prepare("UPDATE hospital SET hospital_name = ?, contact_person = ?, email = ?, phone = ?, address = ? WHERE id = ?");
            if ($stmt === false) {
                die("Prepare failed: " . $conn->error);
            }
            $stmt->bind_param("sssssi", $hospital_name, $contact_person, $email, $phone, $address, $hospital_id);
        }

        if ($stmt->execute()) {
            echo "Profile updated successfully.";
        } else {
            echo "Error updating profile: " . $conn->error;
        }
        $stmt->close();
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Hospital Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-dark bg-dark p-3">
    <a class="navbar-brand" href="hospitaldashboard.php">Hospital Dashboard</a>
    <a href="#" class="btn btn-secondary" onclick="confirmLogout()"><i class="fas fa-arrow-left"></i> Logout</a>
</nav>
<div class="container mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="list-group">
                <a href="hospitaldashboard.php" class="list-group-item list-group-item-action">Dashboard</a>
                <a href="hospital_update.php" class="list-group-item list-group-item-action active">Update Profile</a>
                <a href="manage_patients.php" class="list-group-item list-group-item-action">Manage Patients</a>
                <a href="request_organ.php" class="list-group-item list-group-item-action">Request Organ</a>
         
                <a href="hospital_notifications.php" class="list-group-item list-group-item-action">Notifications</a>
                <a href="#" class="list-group-item list-group-item-action" onclick="confirmLogout()">Logout</a>
            </div>
        </div>
        <div class="col-md-9">
            <h3>Update Profile</h3>
            <div class="card mt-4">
                <div class="card-body">
                   <form method="POST" action="hospital_update.php">
    <div class="mb-3">
        <label for="hospital_name" class="form-label">Hospital Name</label>
        <input type="text" class="form-control" id="hospital_name" name="hospital_name" value="<?php echo htmlspecialchars($hospital_profile['hospital_name'] ?? ''); ?>" required>
    </div>
    <div class="mb-3">
        <label for="contact_person" class="form-label">Contact Person</label>
        <input type="text" class="form-control" id="contact_person" name="contact_person" value="<?php echo htmlspecialchars($hospital_profile['contact_person'] ?? ''); ?>" required>
    </div>
    <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($hospital_profile['email'] ?? ''); ?>" required>
    </div>
    <div class="mb-3">
        <label for="phone" class="form-label">Phone</label>
        <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($hospital_profile['phone'] ?? ''); ?>" required>
    </div>
    <div class="mb-3">
        <label for="address" class="form-label">Address</label>
        <input type="text" class="form-control" id="address" name="address" value="<?php echo htmlspecialchars($hospital_profile['address'] ?? ''); ?>" required>
    </div>
    <div class="mb-3">
        <label for="new_password" class="form-label">New Password (Leave blank to keep current password)</label>
        <input type="password" class="form-control" id="new_password" name="new_password">
    </div>
    <button type="submit" class="btn btn-primary">Update Profile</button>
</form>

                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function confirmLogout() {
        if (confirm("Are you sure you want to log out?")) {
            window.location.href = "home.html"; // Replace with the home page URL
        }
    }
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
