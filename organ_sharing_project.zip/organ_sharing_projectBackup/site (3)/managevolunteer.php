<?php
session_start();
include 'db_connection.php';

$search_query = '';
if (isset($_POST['search'])) {
    $search_query = $_POST['search_query'];
}

try {
    $volunteers = [];
    $stmt = $conn->prepare("SELECT id, full_name, dob, email, address, phone, blood_group, gender, time_of_contribution, area_of_interest, photo FROM volunteer WHERE full_name LIKE ?");
    $search_param = "%" . $search_query . "%";
    $stmt->bind_param("s", $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $volunteers[] = $row;
        }
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Volunteers</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <div class="container-fluid">
            <a class="navbar-brand" href="d1.php">Admin Dashboard</a>
            <a href="d1.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>

        <h3>Manage Volunteers</h3>
        
        <!-- Search Form -->
        <form method="post" class="mb-3">
            <div class="input-group">
                <input type="text" name="search_query" class="form-control" placeholder="Search for a volunteer" value="<?php echo htmlspecialchars($search_query); ?>">
                <button type="submit" name="search" class="btn btn-primary"><i class="fas fa-search"></i> Search</button>
            </div>
        </form>
        
        <a href="add_volunteer.php" class="btn btn-primary mb-3"><i class="fas fa-plus"></i> Add Volunteer</a>
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>DOB</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>Blood Group</th>
                    <th>Gender</th>
                    <th>Time of Contribution</th>
                    <th>Area of Interest</th>
                    <th>Photo</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($volunteers) > 0): ?>
                    <?php foreach ($volunteers as $volunteer): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($volunteer['id']); ?></td>
                            <td><?php echo htmlspecialchars($volunteer['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($volunteer['dob']); ?></td>
                            <td><?php echo htmlspecialchars($volunteer['email']); ?></td>
                            <td><?php echo htmlspecialchars($volunteer['address']); ?></td>
                            <td><?php echo htmlspecialchars($volunteer['phone']); ?></td>
                            <td><?php echo htmlspecialchars($volunteer['blood_group']); ?></td>
                            <td><?php echo htmlspecialchars($volunteer['gender']); ?></td>
                            <td><?php echo htmlspecialchars($volunteer['time_of_contribution']); ?></td>
                            <td><?php echo htmlspecialchars($volunteer['area_of_interest']); ?></td>
                            <td><img src="<?php echo htmlspecialchars($volunteer['photo']); ?>" alt="Photo" style="width: 50px; height: 50px;"></td>
                            <td>
                                <button class="btn btn-warning btn-sm edit-btn" data-id="<?php echo $volunteer['id']; ?>" data-name="<?php echo $volunteer['full_name']; ?>" data-dob="<?php echo $volunteer['dob']; ?>" data-email="<?php echo $volunteer['email']; ?>" data-address="<?php echo $volunteer['address']; ?>" data-phone="<?php echo $volunteer['phone']; ?>" data-blood_group="<?php echo $volunteer['blood_group']; ?>" data-gender="<?php echo $volunteer['gender']; ?>" data-time_of_contribution="<?php echo $volunteer['time_of_contribution']; ?>" data-area_of_interest="<?php echo $volunteer['area_of_interest']; ?>" data-photo="<?php echo $volunteer['photo']; ?>"><i class="fas fa-edit"></i> Edit</button>
                                <a href="delete_volunteer.php?id=<?php echo $volunteer['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?');"><i class="fas fa-trash"></i> Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="12" class="text-center">No volunteers found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Edit Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit Volunteer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editForm" action="update_volunteer.php" method="POST">
                        <input type="hidden" id="edit_id" name="id">
                        <div class="mb-3">
                            <label for="edit_name" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="edit_name" name="full_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_dob" class="form-label">Date of Birth</label>
                            <input type="date" class="form-control" id="edit_dob" name="dob" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="edit_email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_address" class="form-label">Address</label>
                            <textarea class="form-control" id="edit_address" name="address" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="edit_phone" class="form-label">Phone</label>
                            <input type="text" class="form-control" id="edit_phone" name="phone" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_blood_group" class="form-label">Blood Group</label>
                            <input type="text" class="form-control" id="edit_blood_group" name="blood_group" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_gender" class="form-label">Gender</label>
                            <input type="text" class="form-control" id="edit_gender" name="gender" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_time_of_contribution" class="form-label">Time of Contribution</label>
                            <input type="text" class="form-control" id="edit_time_of_contribution" name="time_of_contribution" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_area_of_interest" class="form-label">Area of Interest</label>
                            <input type="text" class="form-control" id="edit_area_of_interest" name="area_of_interest" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_photo" class="form-label">Photo URL</label>
                            <input type="text" class="form-control" id="edit_photo" name="photo" required>
</div>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('.edit-btn').click(function() {
                $('#edit_id').val($(this).data('id'));
                $('#edit_name').val($(this).data('name'));
                $('#edit_dob').val($(this).data('dob'));
                $('#edit_email').val($(this).data('email'));
                $('#edit_address').val($(this).data('address'));
                $('#edit_phone').val($(this).data('phone'));
                $('#edit_blood_group').val($(this).data('blood_group'));
                $('#edit_gender').val($(this).data('gender'));
                $('#edit_time_of_contribution').val($(this).data('time_of_contribution'));
                $('#edit_area_of_interest').val($(this).data('area_of_interest'));
                $('#edit_photo').val($(this).data('photo'));
                $('#editModal').modal('show');
            });
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>