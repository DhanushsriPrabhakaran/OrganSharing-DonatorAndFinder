<?php
// Database connection
$servername = "localhost";
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "project"; // Your database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $hospital_name = $_POST['hospital_name'];
    $contact_person = $_POST['contact_person'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $password = $_POST['password'];

    // Check if email is already registered
    $check_email_sql = "SELECT email FROM hospital WHERE email='$email'";
    $result = $conn->query($check_email_sql);

    if ($result->num_rows > 0) {
        echo "<script>alert('Email is already registered. Please use a different email.'); window.location.href = 'newhospital.php';</script>";
    } else {
        // Hash the password before storing it
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert form data into the database
        $sql = "INSERT INTO hospital (hospital_name, contact_person, email, phone, address, password) 
                VALUES ('$hospital_name', '$contact_person', '$email', '$phone', '$address', '$hashed_password')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('New hospital registered successfully!'); window.location.href = 'hospitallogin.php';</script>";
        } else {
            echo "<script>alert('Error: " . $conn->error . "');</script>";
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hospital Registration</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f9f9f9;
    }
    header {
      background-color: #333;
      color: #fff;
      padding: 10px 20px;
      margin-bottom: 20px;
    }
    header h1 {
      margin: 0;
      font-size: 1.5rem;
    }
    header nav a {
      color: #fff;
      text-decoration: none;
      margin-right: 15px;
    }
    header nav a:last-child {
      margin-right: 0;
    }
    .container {
      max-width: 800px;
      margin: 0px auto;
      background: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .form-title {
      text-align: center;
      margin-bottom: 20px;
    }
    .form-title h2 {
      font-size: 24px;
      color: #333;
    }
    .form-title span {
      color: #e74c3c;
    }
    form {
      display: grid;
      gap: 20px;
    }
    label {
      font-size: 14px;
      color: #555;
    }
    input, select, textarea {
      width: 100%;
      padding: 10px;
      font-size: 14px;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
    }
    .form-row {
      display: flex;
      gap: 20px;
    }
    .form-row > div {
      flex: 1;
    }
    .checkbox-group, .radio-group {
      display: flex;
      gap: 10px;
      align-items: center;
      flex-wrap: wrap;
    }
    .submit-btn {
      background-color:  #D3935C;
      color: #fff;
      border: none;
      padding: 12px 20px;
      font-size: 16px;
      cursor: pointer;
      border-radius: 5px;
      transition: 0.3s;
    }
    .submit-btn:hover {
      background-color: #c0392b;
    }
    .password-strength {
      margin-top: 10px;
      font-size: 14px;
      font-weight: bold;
    }
.login-link {
            text-align: center;
            margin-top: 20px;
        }

        .login-link a {
            text-decoration: none;
            color: black;
            font-weight: bold;
            font-size: 1em;
            transition: color 0.3s ease-in-out;
        }

        .login-link a:hover {
            color: #d3935c;
        }

  </style>
 <script>
    function checkPasswordStrength() {
      var password = document.getElementById('password').value;
      var strengthMessage = document.getElementById('password-strength');
      var regexUpperCase = /[A-Z]/;
      var regexLowerCase = /[a-z]/;
      var regexNumbers = /[0-9]/;
      var regexSpecialChars = /[!@#$%^&*(),.?":{}|<>]/;

      if (password.length < 8) {
        strengthMessage.textContent = "Password must be at least 8 characters long.";
        strengthMessage.style.color = "red";
      }
      else if (!regexUpperCase.test(password) || !regexLowerCase.test(password)) {
        strengthMessage.textContent = "Password must contain both uppercase and lowercase letters.";
        strengthMessage.style.color = "orange";
      }
      else if (!regexNumbers.test(password)) {
        strengthMessage.textContent = "Password must contain at least one number.";
        strengthMessage.style.color = "orange";
      }
      else if (!regexSpecialChars.test(password)) {
        strengthMessage.textContent = "Password must contain at least one special character.";
        strengthMessage.style.color = "orange";
      }
      else {
        strengthMessage.textContent = "Password is strong.";
        strengthMessage.style.color = "green";
      }
    }
  </script>

</head>
<body>
  <header>
    <div style="display: flex; justify-content: space-between; align-items: center;">
      <h1>ORGAN SHARING</h1>
      <nav>
         <a href="log.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Login</a>

      </nav>
    </div>
  </header>
   <!-- Image Section -->
  <div style="text-align: center; margin-bottom: 0px;">
    <img src="hos.jpeg" alt="ORGAN SHARING" style="max-width: 20%; height: auto; border-radius: 8px;">
  </div>
  <div class="container">
    <div class="form-title">
      <h2>Register Your <span>Hospital</span></h2>
    </div>
    <form action="" method="POST">
      <div>
        <label for="hospital_name"><strong>Hospital Name *</strong></label>
        <input type="text" id="hospital_name" name="hospital_name" required>
      </div>
      <div>
        <label for="contact_person"><strong>Contact Person *</strong></label>
        <input type="text" id="contact_person" name="contact_person" required>
      </div>
      <div>
        <label for="email"><strong>Email *</strong></label>
        <input type="email" id="email" name="email" required>
      </div>
      <div>
        <label for="phone"><strong>Phone Number *</strong></label>
        <input type="tel" id="phone" name="phone" required>
      </div>
      <div>
        <label for="address"><strong>Address *</strong></label>
        <textarea id="address" name="address" rows="2" required></textarea>
      </div>
      <div>
        <label for="password"><strong>Password *</strong></label>
        <input type="password" id="password" name="password" required onkeyup="checkPasswordStrength()">
        <div id="password-strength" class="password-strength"></div>
      </div>
      <button type="submit" class="submit-btn">Register</button>
    </form>
<div class="login-link">
                <p>Already registered? <a href="hospitallogin.php">Login here</a></p>
            </div>
  </div>
</body>
</html>
