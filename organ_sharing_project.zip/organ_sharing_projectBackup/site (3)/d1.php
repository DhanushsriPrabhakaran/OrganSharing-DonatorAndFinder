<?php
session_start();

include 'db_connection.php';

try {
    // Initialize counts with default value
    $total_donors = 0;
    $total_hospitals = 0;
    $total_volunteers = 0;
    $active_requests = 0; // Initialize active requests if needed

    // Fetch total donor count
    $result = $conn->query("SELECT COUNT(*) as total_donors FROM donor");
    if ($result && $row = $result->fetch_assoc()) {
        $total_donors = $row['total_donors'];
    }

    // Fetch total hospital count
    $result = $conn->query("SELECT COUNT(*) as total_hospitals FROM hospital");
    if ($result && $row = $result->fetch_assoc()) {
        $total_hospitals = $row['total_hospitals'];
    }

    // Fetch total volunteer count
    $result = $conn->query("SELECT COUNT(*) as total_volunteers FROM volunteer");
    if ($result && $row = $result->fetch_assoc()) {
        $total_volunteers = $row['total_volunteers'];
    }

    // Fetch active requests count (adjust the query as per your requirement)
    $result = $conn->query("SELECT COUNT(*) as active_requests FROM donation_requests WHERE status = 'active'");
    if ($result && $row = $result->fetch_assoc()) {
        $active_requests = $row['active_requests'];
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>

<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <a class="navbar-brand" href="d1.php">Admin Dashboard</a>
        <a href="#" class="btn btn-secondary" onclick="confirmLogout()"><i class="fas fa-arrow-left"></i> Back to Login</a>
    </nav>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="list-group">
                    <a href="#" class="list-group-item list-group-item-action active">Dashboard</a>
                    <a href="managedonor.php" class="list-group-item list-group-item-action">Manage Donors</a>
                    <a href="managehospital.php" class="list-group-item list-group-item-action">Manage Hospital</a>
                    <a href="managevolunteer.php" class="list-group-item list-group-item-action">Manage Volunteers</a>
                    <a href="approve_reject.php" class="list-group-item list-group-item-action">Approve/Reject</a>
                    <a href="add_events.php" class="list-group-item list-group-item-action">Add Events</a>
<a href="event_participants.php" class="list-group-item list-group-item-action">Event Participants</a>
                                        <a href="notifications.php" class="list-group-item list-group-item-action">Post Notifications</a>
                    <a href="#" class="list-group-item list-group-item-action" onclick="confirmLogout()">Logout</a>
                </div>
            </div>
            <div class="col-md-9">
                <h3>Welcome, Admin</h3>
                <div class="row mt-4">
                    <div class="col-md-3">
                        <div class="card bg-info text-white p-3">
                            <h5>Total Donors</h5>
                            <h3><?php echo htmlspecialchars($total_donors); ?></h3>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="card bg-warning text-dark p-3">
                            <h5>Volunteers</h5>
                            <h3><?php echo htmlspecialchars($total_volunteers); ?></h3>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-primary text-white p-3">
                            <h5>Total Hospitals</h5>
                            <h3><?php echo htmlspecialchars($total_hospitals); ?></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function confirmLogout() {
            if (confirm("Are you sure you want to log out?")) {
                window.location.href = "home.html"; // Replace with the home page URL
            }
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
