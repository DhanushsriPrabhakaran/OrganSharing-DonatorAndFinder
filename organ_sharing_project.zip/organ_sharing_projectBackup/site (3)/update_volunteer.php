<?php
session_start();
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $full_name = $_POST['full_name'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $blood_group = $_POST['blood_group'];
    $gender = $_POST['gender'];
    $time_of_contribution = $_POST['time_of_contribution'];
    $area_of_interest = $_POST['area_of_interest'];
    $photo = $_POST['photo'];

    try {
        $stmt = $conn->prepare("UPDATE volunteer SET full_name=?, dob=?, email=?, address=?, phone=?, blood_group=?, gender=?, time_of_contribution=?, area_of_interest=?, photo=? WHERE id=?");
        $stmt->bind_param("ssssssssssi", $full_name, $dob, $email, $address, $phone, $blood_group, $gender, $time_of_contribution, $area_of_interest, $photo, $id);

        if ($stmt->execute()) {
            $_SESSION['success'] = "Volunteer details updated successfully!";
        } else {
            $_SESSION['error'] = "Failed to update volunteer details.";
        }

        $stmt->close();
    } catch (Exception $e) {
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }
    
    header("Location: managevolunteer.php");
    exit();
} else {
    $_SESSION['error'] = "Invalid request!";
    header("Location: managevolunteer.php");
    exit();
}
?>
