<?php
session_start();
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = htmlspecialchars($_POST['title']);
    $message = htmlspecialchars($_POST['message']);

    $stmt = $conn->prepare("INSERT INTO notifications (title, message, created_at) VALUES (?, ?, NOW())");
    $stmt->bind_param("ss", $title, $message);

    if ($stmt->execute()) {
        $success = "Notification posted successfully!";
    } else {
        $error = "Error posting notification: " . $stmt->error;
    }
    $stmt->close();
}

// Fetch notifications
$notifications = [];
$result = $conn->query("SELECT * FROM notifications ORDER BY created_at DESC");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post Notifications</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>

<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <a class="navbar-brand" href="d1.php">Admin Dashboard</a>
        <a href="d1.php" class="btn btn-secondary" ><i class="fas fa-arrow-left"></i> Back to dashboard</a>
    </nav>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="list-group">
                    <a href="d1.php" class="list-group-item list-group-item-action">Dashboard</a>
                    <a href="managedonor.php" class="list-group-item list-group-item-action">Manage Donors</a>
                    <a href="managehospital.php" class="list-group-item list-group-item-action">Manage Hospital</a>
                    <a href="managevolunteer.php" class="list-group-item list-group-item-action">Manage Volunteers</a>
                    <a href="approve_reject.php" class="list-group-item list-group-item-action">Approve/Reject</a>
                    <a href="add_events.php" class="list-group-item list-group-item-action">Add Events</a>
<a href="event_participants.php" class="list-group-item list-group-item-action">Event Participants</a>
                    <a href="notifications.php" class="list-group-item list-group-item-action active">Post Notifications</a>
                    <a href="#" class="list-group-item list-group-item-action" onclick="confirmLogout()">Logout</a>
                </div>
            </div>
            <div class="col-md-9">
                <h3>Post Notifications</h3>
                <?php if (isset($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                <form method="post" action="notifications.php" class="mb-4">
                    <div class="mb-3">
                        <label for="title" class="form-label">Title</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label">Message</label>
                        <textarea class="form-control" id="message" name="message" rows="4" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Post Notification</button>
                </form>
                <h4>Existing Notifications</h4>
                <ul class="list-group">
                    <?php foreach ($notifications as $notification): ?>
                        <li class="list-group-item">
                            <h5><?php echo htmlspecialchars($notification['title']); ?></h5>
                            <p><?php echo htmlspecialchars($notification['message']); ?></p>
                            <small>Posted on <?php echo htmlspecialchars($notification['created_at']); ?></small>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>

   
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
