<?php
session_start();
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $blood_group = $_POST['blood_group'];
    $organs = implode(", ", $_POST['organs']); // Preferred Organs for Donation
    $emergency_contact_name = $_POST['emergency_contact_name'];
    $emergency_contact_phone = $_POST['emergency_contact_phone'];

    try {
        $stmt = $conn->prepare("INSERT INTO donor (full_name, dob, gender, phone, email, address, blood_group, organs, emergency_contact_name, emergency_contact_phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssssss", $full_name, $dob, $gender, $phone, $email, $address, $blood_group, $organs, $emergency_contact_name, $emergency_contact_phone);

        if ($stmt->execute()) {
            $_SESSION['success'] = "Donor added successfully!";
        } else {
            $_SESSION['error'] = "Failed to add donor.";
        }

        $stmt->close();
    } catch (Exception $e) {
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }

    // Redirect to managedonor.php after adding the donor
    header("Location: managedonor.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Donor</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <a class="navbar-brand" href="admindashboard.php">Admin Dashboard</a>
        <a href="managedonor.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back </a>
    </nav>

    <div class="container mt-4">
        <h3>Add Donor</h3>
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>

        <form action="add_donor.php" method="POST">
            <div class="mb-3">
                <label for="full_name" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="full_name" name="full_name" required>
            </div>
            <div class="mb-3">
                <label for="dob" class="form-label">Date of Birth</label>
                <input type="date" class="form-control" id="dob" name="dob">
            </div>
            <div class="mb-3">
                <label for="gender" class="form-label">Gender</label>
                <select class="form-control" id="gender" name="gender" required>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="phone" class="form-label">Phone</label>
                <input type="tel" class="form-control" id="phone" name="phone" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email">
            </div>
            <div class="mb-3">
                <label for="address" class="form-label">Address</label>
                <textarea class="form-control" id="address" name="address" required></textarea>
            </div>
            <div class="mb-3">
                <label for="blood_group" class="form-label">Blood Group</label>
                <select class="form-control" id="blood_group" name="blood_group">
                    <option value="" disabled selected>Select</option>
                    <option value="A+">A+</option>
                    <option value="B+">B+</option>
                    <option value="O+">O+</option>
                    <option value="AB+">AB+</option>
                    <option value="A-">A-</option>
                    <option value="B-">B-</option>
                    <option value="O-">O-</option>
                    <option value="AB-">AB-</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="organs" class="form-label">Preferred Organs for Donation</label>
                <div class="checkbox-group">
                    <label><input type="checkbox" name="organs[]" value="Heart"> Heart</label>
                    <label><input type="checkbox" name="organs[]" value="Kidney"> Kidney</label>
                    <label><input type="checkbox" name="organs[]" value="Liver"> Liver</label>
                    <label><input type="checkbox" name="organs[]" value="Lungs"> Lungs</label>
                    <label><input type="checkbox" name="organs[]" value="Corneas"> Corneas</label>
                    <label><input type="checkbox" name="organs[]" value="Pancreas"> Pancreas</label>
                </div>
            </div>
            <div class="mb-3">
                <label for="emergency_contact_name" class="form-label">Emergency Contact Name</label>
                <input type="text" class="form-control" id="emergency_contact_name" name="emergency_contact_name" required>
            </div>
            <div class="mb-3">
                <label for="emergency_contact_phone" class="form-label">Emergency Contact Phone</label>
                <input type="tel" class="form-control" id="emergency_contact_phone" name="emergency_contact_phone" required>
            </div>
            <button type="submit" class="btn btn-primary">Add Donor</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
