<?php
session_start();
include 'db_connection.php';

if (!isset($_SESSION['donor_id'])) {
    header("Location: donorlogin.php");
    exit();
}

$donor_id = $_SESSION['donor_id'];
$error_message = "";

// Fetch donation history
$donation_history = [];
try {
    $stmt = $conn->prepare("SELECT * FROM donation_history WHERE donor_id = ?");
    $stmt->bind_param("i", $donor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $donation_history[] = $row;
    }
    $stmt->close();
} catch (Exception $e) {
    $error_message = "Error fetching donation history: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donation History</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <a class="navbar-brand" href="donordashboard.php">Donor Dashboard</a>
        <a href="donorlogout.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Logout</a>
    </nav>
    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Donation History</h4>
                        <?php if ($error_message): ?>
                            <div class="alert alert-danger"><?php echo $error_message; ?></div>
                        <?php endif; ?>
                        <?php if (empty($donation_history)): ?>
                            <div class="alert alert-info">No donation history available.</div>
                        <?php else: ?>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Details</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($donation_history as $history): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($history['date']); ?></td>
                                            <td><?php echo htmlspecialchars($history['details']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
