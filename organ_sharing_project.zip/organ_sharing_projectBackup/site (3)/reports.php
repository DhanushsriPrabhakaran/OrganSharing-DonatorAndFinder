<?php
session_start();
include 'db_connection.php';

$data = [
    'total_donors' => 0,
    'total_hospitals' => 0,
    'total_volunteers' => 0,
    'pending_requests' => 0,
    'approved_requests' => 0,
    'rejected_requests' => 0,
    'total_approved_donations' => 0,
    'total_rejected_donations' => 0,
];

try {
    // Fetch total donors
    $result = $conn->query("SELECT COUNT(*) as total_donors FROM donor");
    if ($result && $row = $result->fetch_assoc()) {
        $data['total_donors'] = $row['total_donors'];
    }

    // Fetch total hospitals
    $result = $conn->query("SELECT COUNT(*) as total_hospitals FROM hospital");
    if ($result && $row = $result->fetch_assoc()) {
        $data['total_hospitals'] = $row['total_hospitals'];
    }

    // Fetch total volunteers
    $result = $conn->query("SELECT COUNT(*) as total_volunteers FROM volunteer");
    if ($result && $row = $result->fetch_assoc()) {
        $data['total_volunteers'] = $row['total_volunteers'];
    }

    // Fetch donation request statuses
    $result = $conn->query("SELECT status, COUNT(*) as count FROM donation_requests GROUP BY status");
    while ($row = $result->fetch_assoc()) {
        if ($row['status'] === 'pending') {
            $data['pending_requests'] = $row['count'];
        } elseif ($row['status'] === 'approved') {
            $data['approved_requests'] = $row['count'];
        } elseif ($row['status'] === 'rejected') {
            $data['rejected_requests'] = $row['count'];
        }
    }

    // Fetch approved donations
    $result = $conn->query("SELECT COUNT(*) as total_approved_donations FROM donation_requests WHERE status = 'approved'");
    if ($result && $row = $result->fetch_assoc()) {
        $data['total_approved_donations'] = $row['total_approved_donations'];
    }

    // Fetch rejected donations
    $result = $conn->query("SELECT COUNT(*) as total_rejected_donations FROM donation_requests WHERE status = 'rejected'");
    if ($result && $row = $result->fetch_assoc()) {
        $data['total_rejected_donations'] = $row['total_rejected_donations'];
    }

    // Fetch donations by organ type
    $organ_data = [];
    $result = $conn->query("SELECT organ_type, COUNT(*) as count FROM donation_requests WHERE status = 'approved' GROUP BY organ_type");
    while ($row = $result->fetch_assoc()) {
        $organ_data[] = $row;
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports & Analytics</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <a class="navbar-brand" href="d1.php">Admin Dashboard</a>
        <a href="d1.php" class="btn btn-secondary" ><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </nav>

    <div class="container mt-4">
        <h3>Reports & Analytics</h3>
        <div class="row">
            <div class="col-md-4">
                <div class="card bg-info text-white p-3">
                    <h5>Total Donors</h5>
                    <h3><?php echo htmlspecialchars($data['total_donors']); ?></h3>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-success text-white p-3">
                    <h5>Total Hospitals</h5>
                    <h3><?php echo htmlspecialchars($data['total_hospitals']); ?></h3>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-warning text-dark p-3">
                    <h5>Total Volunteers</h5>
                    <h3><?php echo htmlspecialchars($data['total_volunteers']); ?></h3>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-6">
                <canvas id="donationRequestsChart"></canvas>
            </div>
            <div class="col-md-6">
                <canvas id="organTypeChart"></canvas>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-6">
                <div class="card bg-primary text-white p-3">
                    <h5>Total Approved Donations</h5>
                    <h3><?php echo htmlspecialchars($data['total_approved_donations']); ?></h3>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card bg-danger text-white p-3">
                    <h5>Total Rejected Donations</h5>
                    <h3><?php echo htmlspecialchars($data['total_rejected_donations']); ?></h3>
                </div>
            </div>
        </div>
    </div>

    <script>
        function confirmLogout() {
            if (confirm("Are you sure you want to log out?")) {
                window.location.href = "home.html"; // Replace with the home page URL
            }
        }

        // Data for donation requests chart
        const donationRequestsData = {
            labels: ['Pending', 'Approved', 'Rejected'],
            datasets: [{
                label: 'Donation Requests',
                data: [<?php echo $data['pending_requests']; ?>, <?php echo $data['approved_requests']; ?>, <?php echo $data['rejected_requests']; ?>],
                backgroundColor: ['#FFC107', '#28A745', '#DC3545'],
            }]
        };

        // Config for donation requests chart
        const donationRequestsConfig = {
            type: 'doughnut',
            data: donationRequestsData,
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.label + ': ' + context.raw;
                            }
                        }
                    }
                }
            }
        };

        // Data for organ type chart
        const organTypeData = {
            labels: <?php echo json_encode(array_column($organ_data, 'organ_type')); ?>,
            datasets: [{
                label: 'Approved Donations by Organ Type',
                data: <?php echo json_encode(array_column($organ_data, 'count')); ?>,
                backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'],
            }]
        };

        // Config for organ type chart
        const organTypeConfig = {
            type: 'bar',
            data: organTypeData,
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.label + ': ' + context.raw;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        };

        // Render charts
        window.onload = function() {
            const donationRequestsCtx = document.getElementById('donationRequestsChart').getContext('2d');
            new Chart(donationRequestsCtx, donationRequestsConfig);

            const organTypeCtx = document.getElementById('organTypeChart').getContext('2d');
            new Chart(organTypeCtx, organTypeConfig);
        };
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
