<?php
session_start(); // Start session

$error_message = ""; // Initialize error message

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'project');

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve form data
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Prepare SQL query to check if the username exists
    $stmt = $conn->prepare("SELECT username, password FROM admin WHERE username = ?");
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error); // Add this line to display the SQL error
    }
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($admin_username, $stored_password);

    if ($stmt->num_rows > 0) {
        $stmt->fetch();

        if ($password === $stored_password) {
            // Password is correct, set session variables
            $_SESSION['admin_username'] = $admin_username;
            header("Location: d1.php"); // Redirect to dashboard
            exit();
        } else {
            $error_message = "Incorrect password!";
        }
    } else {
        $error_message = "No admin found with that username!";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            height: 100vh;
            background-color: #f8f9fa;
        }
        .container {
            display: flex;
            width: 100%;
        }
        .left-section {
            width: 40%;
            background: #e3f2fd;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .left-section img {
            max-width: 80%;
            height: auto;
        }
        .right-section {
            width: 60%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            background: #ffffff;
            padding: 40px;
        }
        .login-box {
            width: 100%;
            max-width: 400px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background: white;
            border-radius: 10px;
            text-align: center;
        }
        .error-message {
            background: #ffdddd;
            color: #d9534f;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
        }
        input {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            display: block;
        }
        button {
            width: 100%;
            padding: 12px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background: #0056b3;
        }
        .register-link {
            margin-top: 10px;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Left Section with Image -->
        <div class="left-section">
            <img src="admin.gif" alt="Hospital">
        </div>

        <!-- Right Section with Login Form -->
        <div class="right-section">
            <div class="login-box">
                <h2>Admin Login</h2>
                <form method="POST" action="">
                    <input type="text" name="username" placeholder="Username" required><br>
                    <input type="password" name="password" placeholder="Password" required><br>
                    <?php if ($error_message): ?>
                        <div class="error-message"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    <button type="submit">Login</button>
                </form>
                            </div>
        </div>
    </div>
</body>
</html>
