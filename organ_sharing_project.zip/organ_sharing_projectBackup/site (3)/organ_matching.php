<?php
session_start();
include 'db_connection.php';

$message = '';

try {
    // Fetch patients who need organs
    $patients_query = "SELECT id, blood_type, organ_needed FROM patients WHERE status = 'waiting'";
    $patients_result = $conn->query($patients_query);

    if (!$patients_result) {
        throw new Exception("Error executing patients query: " . $conn->error);
    }

    // Fetch approved donors
    $donors_query = "SELECT id, blood_group, organs FROM donor WHERE consent = 1 AND status = 'approved'";
    $donors_result = $conn->query($donors_query);

    if (!$donors_result) {
        throw new Exception("Error executing donors query: " . $conn->error);
    }

    // Process matching
    while ($patient = $patients_result->fetch_assoc()) {
        $patient_id = $patient['id'];
        $patient_blood_type = $patient['blood_type'];
        $organ_needed = $patient['organ_needed'];

        $match_found = false;
        while ($donor = $donors_result->fetch_assoc()) {
            $donor_id = $donor['id'];
            $donor_blood_type = $donor['blood_group'];
            $donor_organs = explode(',', $donor['organs']);

            // Match based on blood type and organ type
            if ($patient_blood_type == $donor_blood_type && in_array($organ_needed, $donor_organs)) {
                // Update patient and donor status
                $update_patient = "UPDATE patients SET status = 'matched', organ_id = $donor_id WHERE id = $patient_id";
                $update_donor = "UPDATE donor SET status = 'matched' WHERE id = $donor_id";
                $conn->query($update_patient);
                $conn->query($update_donor);

                // Record matching details
                $matching_record = "INSERT INTO organ_matching (patient_id, donor_id, organ_type, status) VALUES ($patient_id, $donor_id, '$organ_needed', 'matched')";
                $conn->query($matching_record);

                $match_found = true;
                break; // Move to the next patient once a match is found
            }
        }
        // Reset donor result pointer to start of the result set
        $donors_result->data_seek(0);
    }

    $message = "The organ matching process has been completed successfully.";
} catch (Exception $e) {
    $message = "Error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Organ Matching Results</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <a class="navbar-brand" href="hospitaldashboard.php">Hospital Dashboard</a>
        <a href="hospitaldashboard.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </nav>
    
    <div class="container mt-4">
        <div class="alert <?php echo strpos($message, 'Error') === 0 ? 'alert-danger' : 'alert-success'; ?> text-center" role="alert">
            <h4 class="alert-heading"><?php echo strpos($message, 'Error') === 0 ? 'Error!' : 'Success!'; ?></h4>
            <p><?php echo htmlspecialchars($message); ?></p>
        </div>
            </div>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Organ Matching Results</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
   
    
    <div class="container mt-4">
        <h3>Organ Matching Results</h3>
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>Patient ID</th>
                    <th>Donor ID</th>
                    <th>Organ Type</th>
                    <th>Status</th>
                    <th>Match Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include 'db_connection.php';
                $results_query = "SELECT patient_id, donor_id, organ_type, status, match_date FROM organ_matching";
                $results = $conn->query($results_query);

                if (!$results) {
                    echo "<tr><td colspan='5'>Error fetching matching results: " . $conn->error . "</td></tr>";
                } else {
                    while ($row = $results->fetch_assoc()) {
                        echo "<tr>
                                <td>" . htmlspecialchars($row['patient_id']) . "</td>
                                <td>" . htmlspecialchars($row['donor_id']) . "</td>
                                <td>" . htmlspecialchars($row['organ_type']) . "</td>
                                <td>" . htmlspecialchars($row['status']) . "</td>
                                <td>" . htmlspecialchars($row['match_date']) . "</td>
                              </tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </div>

    <script>
        function confirmLogout() {
            if (confirm("Are you sure you want to log out?")) {
                window.location.href = "home.html"; // Replace with the home page URL
            }
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
