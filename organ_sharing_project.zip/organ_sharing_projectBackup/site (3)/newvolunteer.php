<?php
// Database connection
$servername = "localhost";
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "project"; // Your database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST['name'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $blood = $_POST['blood'];
    $gender = $_POST['gender'];
    $time = $_POST['time'];
    $interest = $_POST['interest'];
    $password = $_POST['password'];
    
    // Handle photo upload
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["photo"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if image file is an actual image or fake image
    if (isset($_POST["submit"])) {
        $check = getimagesize($_FILES["photo"]["tmp_name"]);
        if ($check !== false) {
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 0;
        }
    }

    // Check file size
    if ($_FILES["photo"]["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Allow certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "jpeg" && $imageFileType != "png" && $imageFileType != "gif") {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // If everything is ok, try to upload file
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
            echo "The file " . basename($_FILES["photo"]["name"]) . " has been uploaded.";

            // Hash the password before storing it
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Insert form data into the database
            $sql = "INSERT INTO volunteer (full_name, dob, email, address, phone, blood_group, gender, time_of_contribution, area_of_interest, photo, password)
            VALUES ('$name', '$dob', '$email', '$address', '$phone', '$blood', '$gender', '$time', '$interest', '$target_file', '$hashed_password')";

            if ($conn->query($sql) === TRUE) {
                echo "<script>alert('New volunteer registered successfully!'); window.location.href = 'volunteerlogin.php';</script>";
            } else {
                echo "<script>alert('Error: " . $conn->error . "');</script>";
            }
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Volunteer Registration</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f9f9f9;
  background-image: url('tem4.jpeg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}

    
    header {
      background-color: #333;
      color: #fff;
      padding: 10px 20px;
      margin-bottom: 20px;
    }
    header h1 {
      margin: 0;
      font-size: 1.5rem;
    }
    header nav a {
      color: #fff;
      text-decoration: none;
      margin-right: 15px;
    }
    header nav a:last-child {
      margin-right: 0;
    }
    .container {
      max-width: 800px;
      margin: 50px auto;
      background: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .form-title {
      text-align: center;
      margin-bottom: 20px;
    }
    .form-title h2 {
      font-size: 24px;
      color: #333;
    }
    .form-title span {
      color: #e74c3c;
    }
    form {
      display: grid;
      gap: 20px;
    }
    label {
      font-size: 14px;
      color: #555;
    }
    input, select, textarea {
      width: 100%;
      padding: 10px;
      font-size: 14px;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
    }
    .form-row {
      display: flex;
      gap: 20px;
    }
    .form-row > div {
      flex: 1;
    }
    .checkbox-group, .radio-group {
      display: flex;
      gap: 10px;
      align-items: center;
      flex-wrap: wrap;
    }
    .submit-btn {
      background-color:  #D3935C;
      color: #fff;
      border: none;
      padding: 12px 20px;
      font-size: 16px;
      cursor: pointer;
      border-radius: 5px;
      transition: 0.3s;
    }
    .submit-btn:hover {
      background-color: #c0392b;
    }
    .password-strength {
      margin-top: 10px;
      font-size: 14px;
      font-weight: bold;
    }
.login-link {
            text-align: center;
            margin-top: 20px;
        }

        .login-link a {
            text-decoration: none;
            color: black;
            font-weight: bold;
            font-size: 1em;
            transition: color 0.3s ease-in-out;
        }

        .login-link a:hover {
            color: #d3935c;
        }

  </style>
  <script>
    function checkPasswordStrength() {
      var password = document.getElementById('password').value;
      var strengthMessage = document.getElementById('password-strength');
      var regexUpperCase = /[A-Z]/;
      var regexLowerCase = /[a-z]/;
      var regexNumbers = /[0-9]/;
      var regexSpecialChars = /[!@#$%^&*(),.?":{}|<>]/;

      if (password.length < 8) {
        strengthMessage.textContent = "Password must be at least 8 characters long.";
        strengthMessage.style.color = "red";
      }
      else if (!regexUpperCase.test(password) || !regexLowerCase.test(password)) {
        strengthMessage.textContent = "Password must contain both uppercase and lowercase letters.";
        strengthMessage.style.color = "orange";
      }
      else if (!regexNumbers.test(password)) {
        strengthMessage.textContent = "Password must contain at least one number.";
        strengthMessage.style.color = "orange";
      }
      else if (!regexSpecialChars.test(password)) {
        strengthMessage.textContent = "Password must contain at least one special character.";
        strengthMessage.style.color = "orange";
      }
      else {
        strengthMessage.textContent = "Password is strong.";
        strengthMessage.style.color = "green";
      }
    }
  </script>
</head>
<body>
  <header>
    <div style="display: flex; justify-content: space-between; align-items: center;">
      <h1>ORGAN SHARING</h1>
      <nav>
         <a href="log.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Login</a>

      </nav>
    </div>
  </header>
   <!-- Image Section -->
  <div style="text-align: center; margin-bottom: 20px;">
    <img src="vol.png" alt="Organ Donation Initiative" style="max-width: 100%; height: auto; border-radius: 8px;">
  </div>

  <div class="container">
    <div class="form-title">
      <h4>An initiative for organ donation</h4>
      <h2>Join <span>Our Team</span></h2>
    </div>
    <form action="" method="POST" enctype="multipart/form-data">
      <div class="form-row">
        <div>
          <label for="name"><strong>Full Name *</strong></label>
          <input type="text" id="name" name="name" required>
        </div>
        <div>
          <label for="dob"><strong>Date of Birth</strong></label>
          <input type="date" id="dob" name="dob">
        </div>
      </div>
      <div>
        <label for="email"><strong>E-mail</strong></label>
        <input type="email" id="email" name="email">
      </div>
      <div>
        <label for="address"><strong>Address *</strong></label>
        <textarea id="address" name="address" rows="2" required></textarea>
      </div>
      <div class="form-row">
        <div>
          <label for="phone"><strong>Phone No. *</strong></label>
          <input type="tel" id="phone" name="phone" required>
        </div>
        <div>
          <label for="blood"><strong>Blood Group</strong></label>
          <select id="blood" name="blood">
            <option value="" disabled selected>Select</option>
            <option value="A+">A+</option>
            <option value="B+">B+</option>
            <option value="O+">O+</option>
            <option value="AB+">AB+</option>
            <option value="A-">A-</option>
            <option value="B-">B-</option>
            <option value="O-">O-</option>
            <option value="AB-">AB-</option>
          </select>
        </div>
      </div>
      <div class="form-row">
        <div>
          <label for="gender"><strong>Gender *</strong></label>
          <select id="gender" name="gender" required>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
        </div>
        <div>
          <label><strong>Time of Contribution</strong></label>
          <div class="radio-group">
            <label><input type="radio" name="time" value="Full Time"> Full Time</label>
            <label><input type="radio" name="time" value="Part Time"> Part Time</label>
            <label><input type="radio" name="time" value="Any"> Any Time</label>
          </div>
        </div>
      </div>
      <div>
        <label><strong>Area of Interest</strong></label>
        <div class="radio-group">
          <label><input type="radio" name="interest" value="Content Writing"> Content Writing</label>
          <label><input type="radio" name="interest" value="Videography"> Videography</label>
          <label><input type="radio" name="interest" value="Outreach Programs"> Outreach Programs</label>
        </div>
      </div>

      <div>
        <label for="photo"><strong>Photo *</strong></label>
        <input type="file" id="photo" name="photo" required>
      </div>

      <div>
        <label for="password"><strong>Password *</strong></label>
        <input type="password" id="password" name="password" required onkeyup="checkPasswordStrength()">
        <div id="password-strength" class="password-strength"></div>
      </div>

      <button type="submit" class="submit-btn">Register</button>
    </form>
<div class="login-link">
                <p>Already registered? <a href="volunteerlogin.php">Login here</a></p>
            </div>
  </div>
</body>
</html>
