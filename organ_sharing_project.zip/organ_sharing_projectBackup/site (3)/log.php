<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Future of Organ Donation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: white; /* White background */
            color: black; /* Black text */
            overflow-x: hidden;
            background-image: url('tem2.jpeg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;

        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            padding: 50px;
            animation: zoomIn 1.5s ease-in-out;
        }

        .section {
            width: 250px;
            background-color: white; /* #d3935c background */
            margin: 20px;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            animation: bounceIn 2s ease-in-out;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .section img {
            width: 100px;
            height: 100px;
            margin-bottom: 20px;
            object-fit: cover;
        }

        .section h2 {
            font-size: 1.5em;
            color: black; /* Black heading */
            margin: 0;
        }

        .section p {
            font-size: 1em;
            color: black; /* Black text */
            margin: 10px 0 0;
        }

        .section button {
            background-color: white; /* White button background */
            color: #d3935c; /* #d3935c text */
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            font-size: 1em;
            border-radius: 5px;
            margin-top: 10px;
            transition: all 0.3s ease-in-out;
        }

        .section button:hover {
            background-color: #d3935c; /* #d3935c hover effect */
            color: white; /* White text on hover */
            transform: scale(1.05);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
        }

        .section button:active {
            background-color: #b3724d; /* Slightly darker for active state */
            color: white; /* Ensure text stays visible */
            transform: scale(0.98);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes zoomIn {
            from { transform: scale(0); }
            to { transform: scale(1); }
        }

        @keyframes bounceIn {
            from, 20%, 40%, 60%, 80%, to { animation-timing-function: cubic-bezier(0.215, 0.610, 0.355, 1.000); }
            0% { opacity: 0; transform: scale3d(.3, .3, .3); }
            20% { transform: scale3d(1.1, 1.1, 1.1); }
            40% { transform: scale3d(.9, .9, .9); }
            60% { opacity: 1; transform: scale3d(1.03, 1.03, 1.03); }
            80% { transform: scale3d(.97, .97, .97); }
            to { opacity: 1; transform: scale3d(1, 1, 1); }
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="section">
            <img src="admin.jpg" alt="User Icon">
            <button onclick="window.location.href='adminlogin.php'">
                <h2>ADMIN</h2>
                <p>For Portal Management</p>
            </button>
        </div>
        <div class="section">
            <img src="hospital.jpg" alt="Organization Icon">
            <button onclick="window.location.href='newhospital.php'">
                <h2>HOSPITAL</h2>
                <p>For Requesting Organs</p>
            </button>
        </div>
        <div class="section">
            <img src="donor.jpg" alt="Donor Icon">
            <button onclick="window.location.href='newdonor.php'">
                <h2>DONOR</h2>
                <p>For Donating Organs</p>
            </button>
        </div>
        <div class="section">
            <img src="volunteer.jpg" alt="Doctor Icon">
            <button onclick="window.location.href='newvolunteer.php'">
                <h2>VOLUNTEER</h2>
                <p>For Outreach Programmes</p>
            </button>
        </div>
    </div>

</body>
</html>
