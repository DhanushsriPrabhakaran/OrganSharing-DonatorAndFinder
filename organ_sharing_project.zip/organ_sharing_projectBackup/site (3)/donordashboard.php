<?php
session_start();
include 'db_connection.php';

// Ensure the user is logged in
if (!isset($_SESSION['donor_id'])) {
    header("Location: donorlogin.php");
    exit();
}

$donor_id = $_SESSION['donor_id'];
$donor_profile = [];
$notifications = [];
$unread_count = 0;

try {
    // Fetch donor profile using prepared statements
    $stmt = $conn->prepare("SELECT * FROM donor WHERE id = ?");
    if (!$stmt) {
        throw new Exception("Prepare statement for donor profile failed: " . $conn->error);
    }
    $stmt->bind_param("i", $donor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result) {
        $donor_profile = $result->fetch_assoc();
    } else {
        throw new Exception("Donor profile not found.");
    }
    $stmt->close();

    // Fetch notifications using 'id' column
    $stmt = $conn->prepare("SELECT * FROM notifications WHERE id = ?");
    if (!$stmt) {
        throw new Exception("Prepare statement for notifications failed: " . $conn->error);
    }
    $stmt->bind_param("i", $donor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    $stmt->close();

    // Count total notifications
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE id = ?");
    if (!$stmt) {
        throw new Exception("Prepare statement for notifications count failed: " . $conn->error);
    }
    $stmt->bind_param("i", $donor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result) {
        $unread_count = $result->fetch_assoc()['count'];
    } else {
        throw new Exception("Failed to count notifications.");
    }
    $stmt->close();

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donor Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <a class="navbar-brand" href="donordashboard.php">Donor Dashboard</a>
        <button class="btn btn-danger" onclick="confirmLogout()">
            <i class="fas fa-sign-out-alt"></i> Logout
        </button>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3">
                <div class="list-group">
                    <a href="#" class="list-group-item list-group-item-action active">Dashboard</a>
                    <a href="update_profile.php" class="list-group-item list-group-item-action">Update Profile</a>
                    <a href="change_password.php" class="list-group-item list-group-item-action">Change Password</a>
<a href="hospital_requests.php" class="list-group-item list-group-item-action">Hospital Requests</a>
                    <a href="health.php" class="list-group-item list-group-item-action">Health and Wellness</a>
                    <a href="donor_notifications.php" class="list-group-item list-group-item-action">
                        Notifications <?php if ($unread_count > 0) echo "<span class='badge bg-danger'>$unread_count</span>"; ?>
                    </a>
                    <a href="download_donor_id.php" class="list-group-item list-group-item-action">Download Donor ID</a>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9">
                <h2>Welcome, <?php echo htmlspecialchars($donor_profile['full_name'] ?? 'Donor'); ?>!</h2>

                <!-- Profile Card -->
                <div class="card mt-4">
                    <div class="card-body">
                        <h4 class="card-title">Profile Details</h4>
                                                    <div>
                                <p><strong>Name:</strong> <?php echo htmlspecialchars($donor_profile['full_name'] ?? 'N/A'); ?></p>
                                <p><strong>Date of Birth:</strong> <?php echo htmlspecialchars($donor_profile['dob'] ?? 'N/A'); ?></p>
                                <p><strong>Gender:</strong> <?php echo htmlspecialchars($donor_profile['gender'] ?? 'N/A'); ?></p>
                                <p><strong>Email:</strong> <?php echo htmlspecialchars($donor_profile['email'] ?? 'N/A'); ?></p>
                                <p><strong>Phone:</strong> <?php echo htmlspecialchars($donor_profile['phone'] ?? 'N/A'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Organs Donated Table -->
                <div class="card mt-4" id="organs">
                    <div class="card-body">
                        <h4 class="card-title">Organs Donated</h4>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Organ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Display organs from the donor profile
                                $organs = htmlspecialchars($donor_profile['organs'] ?? '');
                                if ($organs) {
                                    $organs_array = explode(',', $organs);
                                    foreach ($organs_array as $organ) {
                                        echo "<tr><td>" . htmlspecialchars($organ) . "</td></tr>";
                                    }
                                } else {
                                    echo "<tr><td class='text-center'>No organs donated</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <script>
        function confirmLogout() {
            if (confirm("Are you sure you want to logout?")) {
                window.location.href = "home.html";
            }
        }
    </script>
</body>
</html>
