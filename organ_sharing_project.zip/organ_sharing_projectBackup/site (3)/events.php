<?php
include 'db_connection.php';

// Handle enrollment
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['event_name'])) {
    $volunteerName = $_POST['volunteer_name'];
    $eventName = $_POST['event_name'];
    $email = $_POST['email'];
    $phoneNumber = $_POST['phone_number'];

    try {
        // Insert enrollment record into participation table
        $stmt = $conn->prepare("INSERT INTO participation (volunteer_name, event_name, email, phone_number) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $volunteerName, $eventName, $email, $phoneNumber);

        if ($stmt->execute()) {
            $successMessage = "Thank you for enrolling!";
        } else {
            $errorMessage = "Error: " . $stmt->error;
        }
        $stmt->close();
    } catch (Exception $e) {
        $errorMessage = "Error: " . $e->getMessage();
    }
}

// Fetch events from the database
try {
    $events = [];
    $stmt = $conn->prepare("SELECT event_name, event_date, location, description FROM events");
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $events[] = $row;
        }
    }
    $stmt->close();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}

// Fetch participation to check enrollment status for each event
$enrolledEvents = [];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email']; // Get the user's email

    try {
        $participationStmt = $conn->prepare("SELECT event_name FROM participation WHERE email = ?");
        $participationStmt->bind_param("s", $email);
        $participationStmt->execute();
        $participationResult = $participationStmt->get_result();

        if ($participationResult) {
            while ($row = $participationResult->fetch_assoc()) {
                $enrolledEvents[] = $row['event_name'];
            }
        }
        $participationStmt->close();
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volunteer Dashboard - Events</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <div class="container-fluid">
            <a class="navbar-brand" href="volunteerdashboard.php">Volunteer Dashboard</a>
            <a href="volunteerdashboard.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($successMessage)): ?>
            <div class="alert alert-success"><?php echo $successMessage; ?></div>
        <?php elseif (isset($errorMessage)): ?>
            <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
        <?php endif; ?>

        <h3>Available Events</h3>

        <div class="event-list">
            <?php if (count($events) > 0): ?>
                <?php foreach ($events as $event): ?>
                    <div class="event border p-3 mb-3">
                        <h4><?php echo htmlspecialchars($event['event_name']); ?></h4>
                        <p><strong>Date:</strong> <?php echo htmlspecialchars($event['event_date']); ?></p>
                        <p><strong>Location:</strong> <?php echo htmlspecialchars($event['location']); ?></p>
                        <p><strong>Description:</strong> <?php echo htmlspecialchars($event['description']); ?></p>
                        <?php if (in_array($event['event_name'], $enrolledEvents)): ?>
                            <button class="btn btn-success" disabled>Enrolled</button>
                        <?php else: ?>
                            <form method="POST">
                                <input type="hidden" name="event_name" value="<?php echo $event['event_name']; ?>">
                                <div class="mb-3">
                                    <label for="volunteer_name">Your Name:</label>
                                    <input type="text" id="volunteer_name" name="volunteer_name" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label for="email">Your Email:</label>
                                    <input type="email" id="email" name="email" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label for="phone_number">Phone Number:</label>
                                    <input type="text" id="phone_number" name="phone_number" class="form-control" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Enroll</button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No events available.</p>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>
