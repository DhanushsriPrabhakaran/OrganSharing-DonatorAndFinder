<?php
session_start(); // Start session

$error_message = ""; // Initialize error message

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'project');

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve form data
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Prepare SQL query to check email, password, and status
    $stmt = $conn->prepare("SELECT id, full_name, password, status FROM donor WHERE email = ?");
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error); // Display SQL error
    }
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($donor_id, $donor_name, $hashed_password, $status);

    if ($stmt->num_rows > 0) {
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            if ($status === 'approved') {
                // Approved users proceed to the dashboard
                $_SESSION['donor_id'] = $donor_id;
                $_SESSION['donor_name'] = $donor_name;
                header("Location: donordashboard.php"); // Redirect to dashboard
                exit();
            } elseif ($status === 'pending') {
                // Pending approval
                $error_message = "Your account is awaiting admin approval. Please try again later.";
            } elseif ($status === 'rejected') {
                // Rejected account
                $error_message = "Your account has been rejected. Contact the admin for further details.";
            }
        } else {
            // Incorrect password
            $error_message = "Incorrect password!";
        }
    } else {
        // No donor found with the entered email
        $error_message = "No donor found with that email!";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donor Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            height: 100vh;
            background-color: #f8f9fa;
        }
        .container {
            display: flex;
            width: 100%;
        }
        .left-section {
            width: 40%;
            background: #e3f2fd;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .left-section img {
            max-width: 80%;
            height: auto;
        }
        .right-section {
            width: 60%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            background: #ffffff;
            padding: 40px;
        }
        .login-box {
            width: 100%;
            max-width: 400px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background: white;
            border-radius: 10px;
            text-align: center;
        }
        .error-message {
            background: #ffdddd;
            color: #d9534f;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
        }
        input {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            display: block;
        }
        button {
            width: 100%;
            padding: 12px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background: #0056b3;
        }
        .register-link {
            margin-top: 10px;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Left Section with Image -->
        <div class="left-section">
            <img src="donor.gif" alt="Hospital">
        </div>

        <!-- Right Section with Login Form -->
        <div class="right-section">
            <div class="login-box">
                <h2>Donor Login</h2>
                <form method="POST" action="">
                    <input type="email" name="email" placeholder="Email" required><br>
                    <input type="password" name="password" placeholder="Password" required><br>
                    <?php if ($error_message): ?>
                        <div class="error-message"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    <button type="submit">Login</button>
                </form>
                <div class="register-link">
                    <p>Don't have an account? <a href="newdonor.php">Register Here</a></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
