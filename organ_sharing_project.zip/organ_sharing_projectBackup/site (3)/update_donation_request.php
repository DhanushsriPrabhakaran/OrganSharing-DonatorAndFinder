<?php
session_start();
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $request_id = $_POST['request_id'];
    $action = $_POST['action'];

    try {
        if ($action === 'approve') {
            $stmt = $conn->prepare("UPDATE donation_requests SET status = 'approved' WHERE request_id = ?");
        } else {
            $stmt = $conn->prepare("UPDATE donation_requests SET status = 'rejected' WHERE request_id = ?");
        }
        $stmt->bind_param("i", $request_id);

        if ($stmt->execute()) {
            $_SESSION['success'] = "Donation request " . $action . "d successfully!";
        } else {
            $_SESSION['error'] = "Failed to " . $action . " donation request.";
        }

        $stmt->close();
    } catch (Exception $e) {
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }

    header("Location: manage_donation_requests.php");
    exit();
}
?>
