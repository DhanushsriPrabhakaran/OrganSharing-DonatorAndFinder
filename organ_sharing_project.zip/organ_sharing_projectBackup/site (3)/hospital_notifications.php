<?php
session_start();
include 'db_connection.php';

// Fetch notifications
$notifications = [];
$result = $conn->query("SELECT * FROM notifications ORDER BY created_at DESC");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>

<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <a class="navbar-brand" href="hospitaldashboard.php">Hospital Dashboard</a>
        <a href="hospitaldashboard.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to dashboard</a>
    </nav>
    
    <div class="container mt-4">
        <h3>Notifications</h3>
        <ul class="list-group">
            <?php foreach ($notifications as $notification): ?>
                <li class="list-group-item">
                    <h5><?php echo htmlspecialchars($notification['title']); ?></h5>
                    <p><?php echo htmlspecialchars($notification['message']); ?></p>
                    <small>Posted on <?php echo htmlspecialchars($notification['created_at']); ?></small>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>

    <script>
        function confirmLogout() {
            if (confirm("Are you sure you want to log out?")) {
                window.location.href = "home.html"; // Replace with the home page URL
            }
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
