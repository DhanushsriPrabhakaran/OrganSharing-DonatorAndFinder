<?php
session_start();
include 'db_connection.php';

if (!isset($_SESSION['volunteer_id'])) {
    header("Location: volunteerlogin.php");
    exit();
}

try {
    // Fetch volunteer profile details
    $volunteer_id = $_SESSION['volunteer_id'];
    $volunteer_profile = [];
    $result = $conn->query("SELECT * FROM volunteer WHERE id = $volunteer_id");
    if ($result && $row = $result->fetch_assoc()) {
        $volunteer_profile = $row;
    }

    // Fetch events volunteer is participating in
    $events = [];
    $result = $conn->query("SELECT * FROM events WHERE volunteer_id = $volunteer_id");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $events[] = $row;
        }
    }

    // Fetch outreach activities
    $outreach_activities = [];
    $result = $conn->query("SELECT * FROM outreach WHERE volunteer_id = $volunteer_id");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $outreach_activities[] = $row;
        }
    }

    // Fetch notifications for volunteers
    $notifications = [];
    $result = $conn->query("SELECT * FROM notifications WHERE volunteer_id = $volunteer_id");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $notifications[] = $row;
        }
    }

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volunteer Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <a class="navbar-brand" href="volunteer_dashboard.php">Volunteer Dashboard</a>
        <a href="#" class="btn btn-secondary" onclick="confirmLogout()"><i class="fas fa-arrow-left"></i> Logout</a>
    </nav>

    
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-3">
                <div class="list-group">
                    <a href="#" class="list-group-item list-group-item-action active">Dashboard</a>
                    <a href="update_volunteer_profile.php" class="list-group-item list-group-item-action">Update Profile</a>
                    <a href="change_volunteer_password.php" class="list-group-item list-group-item-action">Change Password</a>
                    <a href="events.php" class="list-group-item list-group-item-action">Event Participation</a>
                    <a href="volunteer_notifications.php" class="list-group-item list-group-item-action">Notifications</a>
                    <a href="pledge.php" class="list-group-item list-group-item-action">Take Pledge</a>
                </div>
            </div>
            <div class="col-md-9">
                <h2>Welcome, <?php echo htmlspecialchars($volunteer_profile['full_name'] ?? 'Volunteer'); ?>!</h2>

                <div class="card mt-4">
                    <div class="card-body">
                        <h4 class="card-title">Profile Details</h4>
<div class="d-flex align-items-center">
                            <img src="<?php echo htmlspecialchars($volunteer_profile['photo'] ?? 'default-avatar.png'); ?>" alt="Profile Picture" class="rounded-circle me-3" width="100"> <div>


                        <p class="card-text"><strong>Name:</strong> <?php echo htmlspecialchars($volunteer_profile['full_name'] ?? 'N/A'); ?></p>
                        <p class="card-text"><strong>Email:</strong> <?php echo htmlspecialchars($volunteer_profile['email'] ?? 'N/A'); ?></p>
                        <p class="card-text"><strong>Phone:</strong> <?php echo htmlspecialchars($volunteer_profile['phone'] ?? 'N/A'); ?></p>
                        <p class="card-text"><strong>Area of Interest:</strong> <?php echo htmlspecialchars($volunteer_profile['area_of_interest'] ?? 'N/A'); ?></p>
                    </div>
                </div>

                

            </div>
        </div>
    </div>

    <script>
        function confirmLogout() {
            if (confirm("Are you sure you want to logout?")) {
                window.location.href = "home.html";
            }
        }
    </script>
</body>
</html>
