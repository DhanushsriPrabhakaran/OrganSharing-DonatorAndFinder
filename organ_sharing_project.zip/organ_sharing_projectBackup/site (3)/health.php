<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Health & Wellness for Donors</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f8f9fa;
        }
        .hero {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('health.jpg') no-repeat center center/cover;
            color: white;
            padding: 100px 0;
            text-align: center;
        }
        .hero h1 {
            font-weight: 700;
        }
        .tab-content img, .tab-content video {
            width: 100%;
            border-radius: 10px;
            transition: transform 0.3s ease-in-out;
        }
        .tab-content img:hover, .tab-content video:hover {
            transform: scale(1.05);
        }
        .navbar-dark .navbar-brand {
            color: white;
        }
        .navbar-dark .nav-link {
            color: rgba(255, 255, 255, 0.9);
        }
        .nav-tabs .nav-link.active {
            background-color: #28a745;
            color: white;
        }
        .card {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }
        .card:hover {
            transform: scale(1.02);
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
       <a class="navbar-brand" href="dashboard.php">Donor Dashboard</a>
        <a href="donordashboard.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </nav>

    <div class="hero">
        <h1>Health & Wellness</h1>
        <p>Your guide to a healthy life after donation</p>
    </div>

    <div class="container mt-4">
        <ul class="nav nav-tabs" id="healthTabs">
            <li class="nav-item">
                <a class="nav-link active" data-bs-toggle="tab" href="#articles">Articles</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#tips">Health Tips</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#images">Image Gallery</a>
            </li>
        </ul>

        <div class="tab-content mt-3">
            <div class="tab-pane fade show active" id="articles">
                <h3>Latest Articles</h3>
                <div class="card p-3">
                    <p><b>Maintaining Good Health After Donation</b></p>
                    <p>Stay hydrated, eat a balanced diet, and engage in regular physical activity to maintain good health post-donation.</p>
                </div>
                <div class="card p-3 mt-3">
                    <p><b>Benefits of Organ Donation</b></p>
                    <p>Donating an organ not only saves lives but also promotes personal well-being through a sense of fulfillment and gratitude.</p>
                </div>
            </div>
            <div class="tab-pane fade" id="tips">
                <h3>Health Tips</h3>
<div class="col-md-6">
                         <video autoplay muted loop controls style="width: 500px; height: 500px;" class="mb-3">
                            <source src="tip1.mp4" type="video/mp4">
                            Your browser does not support the video tag.
                        </video>

                    </div>

                <div class="card p-3">
                    <ul>
                        <li><b>Stay Hydrated: </b>Ensure you drink plenty of water daily—at least 8-10 glasses—to aid recovery and maintain energy levels.</li>

 <li><b>Follow a Balanced Diet: </b>Incorporate foods rich in vitamins, proteins, and iron such as leafy greens, lean meats, nuts, and fruits to replenish nutrients.</li>

 <li><b>Get Enough Rest:</b> Adequate sleep (7-9 hours) is crucial for your body to heal and rejuvenate after donation.</li>

 <li><b>Engage in Moderate Exercise:</b> Light activities like walking or yoga can help maintain circulation and overall fitness, but avoid strenuous exercise for a while.</li>

 <li><b>Regular Medical Check-ups:</b> Keep in touch with your healthcare provider for post-donation follow-ups to monitor your health.</li>

 <li><b>Practice Stress Management:</b> Techniques like mindfulness, meditation, or breathing exercises can improve mental health and reduce stress.</li>

 <li><b>Avoid Harmful Habits:</b> Limit alcohol consumption, quit smoking, and avoid any substances that could impact your recovery.</li>

 <li><b>Listen to Your Body:</b> Pay attention to any signs of discomfort or unusual symptoms and consult a doctor if necessary.</li>
                    </ul>
                </div>
            </div>
<div class="tab-pane fade" id="images">
    <div class="row">
    <div class="col-md-6">
      <h5>Healthy Fruits</h5>
      <video autoplay muted loop controls style="width: 500px; height: 500px;" class="mb-3">
        <source src="fruits.mp4" type="video/mp4">
        Your browser does not support the video tag.
      </video>
    </div>
    <div class="col-md-6">
      <h5>Exercise for Wellness</h5>
      <video autoplay muted loop controls style="width: 500px; height: 500px;" class="mb-3">
        <source src="exercise.mp4" type="video/mp4">
        Your browser does not support the video tag.
      </video>
    </div>
    <div class="col-md-6">
      <h5>Nutritious Food</h5>
      <video autoplay muted loop controls style="width: 500px; height: 500px;" class="mb-3">
        <source src="food.mp4" type="video/mp4">
        Your browser does not support the video tag.
      </video>
    </div>
    <div class="col-md-6">
      <h5>Stretching Techniques</h5>
      <video autoplay muted loop controls style="width: 500px; height: 500px;" class="mb-3">
        <source src="stretch.mp4" type="video/mp4">
        Your browser does not support the video tag.
      </video>
    </div>
  </div>
</div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function confirmLogout() {
            if (confirm("Are you sure you want to logout?")) {
                window.location.href = "donordashboard.php";
            }
        }
    </script>
</body>
</html>
