<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch donor data
$donor_sql = "SELECT id, full_name, email, phone, blood_group, organs FROM donor";
$donor_result = $conn->query($donor_sql);

// Fetch hospital data
$hospital_sql = "SELECT id, hospital_name, contact_person, email, phone, address FROM hospital";
$hospital_result = $conn->query($hospital_sql);

// Fetch volunteer data
$volunteer_sql = "SELECT id, full_name, email, phone, gender, age, city, available_hours, preferred_program FROM volunteer";
$volunteer_result = $conn->query($volunteer_sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Styles (Same as earlier) */
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li>
                <a href="#" id="donorMenu"><i class="fas fa-hand-holding-heart"></i> Donor Management</a>
                <ul class="submenu" id="donorSubmenu" style="display: none;">
                    <li><a href="#" id="viewDonor">View Donor Information</a></li>
                    <li><a href="#" id="approveRejectDonor">Approve or Reject Donor</a></li>
                    <li><a href="#" id="editDonor">Edit Donor Information</a></li>
                    <li><a href="#" id="deleteDonor">Delete Donor</a></li>
                    <li><a href="#" id="sendNotification">Send Notifications</a></li>
                </ul>
            </li>
            <li><a href="#" id="hospitalMenu"><i class="fas fa-hospital"></i> Hospital Management</a></li>
            <li><a href="#" id="volunteerMenu"><i class="fas fa-hands-helping"></i> Volunteer Management</a></li>
            <li><a href="#"><i class="fas fa-chart-bar"></i> Reports</a></li>
            <li><a href="#"><i class="fas fa-cog"></i> Settings</a></li>
            <li><a href="#"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>

    <!-- Toggle Button -->
    <button class="toggle-btn" id="toggleBtn">
        <i class="fas fa-arrow-left"></i>
    </button>

    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <!-- Content Sections (Same as earlier) -->
    </div>

    <script>
        const sidebar = document.getElementById('sidebar');
        const toggleBtn = document.getElementById('toggleBtn');
        const mainContent = document.getElementById('mainContent');
        const donorSection = document.getElementById('donorSection');
        const hospitalSection = document.getElementById('hospitalSection');
        const volunteerSection = document.getElementById('volunteerSection');

        const donorMenu = document.getElementById('donorMenu');
        const hospitalMenu = document.getElementById('hospitalMenu');
        const volunteerMenu = document.getElementById('volunteerMenu');

        const donorSubmenu = document.getElementById('donorSubmenu');
        const hospitalSubmenu = document.getElementById('hospitalSubmenu');
        const volunteerSubmenu = document.getElementById('volunteerSubmenu');

        // Toggle Sidebar
        toggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('closed');
            toggleBtn.classList.toggle('closed');
            mainContent.classList.toggle('full-width');
        });

        // Track state of donor submenu
        let isDonorMenuOpen = false;

        // Donor Menu Click Event
        donorMenu.addEventListener('click', () => {
            if (isDonorMenuOpen) {
                donorSubmenu.style.display = 'none';
                isDonorMenuOpen = false;
            } else {
                donorSubmenu.style.display = 'block';
                hospitalSubmenu && (hospitalSubmenu.style.display = 'none');
                volunteerSubmenu && (volunteerSubmenu.style.display = 'none');
                isDonorMenuOpen = true;
            }

            donorSection.style.display = 'block';
            hospitalSection.style.display = 'none';
            volunteerSection.style.display = 'none';
        });

        // Hospital Menu Click Event
        hospitalMenu.addEventListener('click', () => {
            donorSection.style.display = 'none';
            hospitalSection.style.display = 'block';
            volunteerSection.style.display = 'none';

            donorSubmenu.style.display = 'none';
            isDonorMenuOpen = false;
        });

        // Volunteer Menu Click Event
        volunteerMenu.addEventListener('click', () => {
            donorSection.style.display = 'none';
            hospitalSection.style.display = 'none';
            volunteerSection.style.display = 'block';

            donorSubmenu.style.display = 'none';
            isDonorMenuOpen = false;
        });
    </script>
</body>
</html>
