<?php
session_start();

include 'db_connection.php';

// Handle Add Patient form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_patient'])) {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $blood_type = $_POST['blood_type'];
    $organ_needed = $_POST['organ_needed'];

    $stmt = $conn->prepare("INSERT INTO patients (name, age, blood_type, organ_needed) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("siss", $name, $age, $blood_type, $organ_needed);
    $stmt->execute();
    $stmt->close();

    $_SESSION['success'] = "Patient added successfully.";
    header("Location: manage_patients.php");
    exit();
}

// Handle Edit Patient form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_patient'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $age = $_POST['age'];
    $blood_type = $_POST['blood_type'];
    $organ_needed = $_POST['organ_needed'];

    $stmt = $conn->prepare("UPDATE patients SET name = ?, age = ?, blood_type = ?, organ_needed = ? WHERE id = ?");
    $stmt->bind_param("sissi", $name, $age, $blood_type, $organ_needed, $id);
    $stmt->execute();
    $stmt->close();

    $_SESSION['success'] = "Patient updated successfully.";
    header("Location: manage_patients.php");
    exit();
}

// Handle Delete Patient form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_patient'])) {
    $id = $_POST['id'];

    $stmt = $conn->prepare("DELETE FROM patients WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();

    $_SESSION['success'] = "Patient deleted successfully.";
    header("Location: manage_patients.php");
    exit();
}

// Fetch all patients from the database
$patients = [];
$result = $conn->query("SELECT * FROM patients");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $patients[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Patients</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <a class="navbar-brand" href="dashboard.php">Hospital Dashboard</a>
        <a href="hospitaldashboard.php" class="btn btn-secondary" ><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </nav>

    <div class="container mt-4">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <h3>Manage Patients</h3>
        <div class="row mt-4">
            <div class="col-md-8">
                <h5>Patient List</h5>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Age</th>
                            <th>Blood Type</th>
                            <th>Organ Needed</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($patients as $patient): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($patient['id']); ?></td>
                            <td><?php echo htmlspecialchars($patient['name']); ?></td>
                            <td><?php echo htmlspecialchars($patient['age']); ?></td>
                            <td><?php echo htmlspecialchars($patient['blood_type']); ?></td>
                            <td><?php echo htmlspecialchars($patient['organ_needed']); ?></td>
                            <td>
                                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editPatientModal<?php echo $patient['id']; ?>">Edit</button>
                                <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deletePatientModal<?php echo $patient['id']; ?>">Delete</button>
                            </td>
                        </tr>

                        <!-- Edit Patient Modal -->
                        <div class="modal fade" id="editPatientModal<?php echo $patient['id']; ?>" tabindex="-1" aria-labelledby="editPatientModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editPatientModalLabel">Edit Patient</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form method="post" action="manage_patients.php">
                                            <input type="hidden" name="id" value="<?php echo $patient['id']; ?>">
                                            <div class="mb-3">
                                                <label for="name" class="form-label">Name</label>
                                                <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($patient['name']); ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="age" class="form-label">Age</label>
                                                <input type="number" class="form-control" id="age" name="age" value="<?php echo htmlspecialchars($patient['age']); ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="blood_type" class="form-label">Blood Type</label>
                                                <select class="form-control" id="blood_type" name="blood_type" required>
                                                    <option value="A+" <?php if ($patient['blood_type'] == 'A+') echo 'selected'; ?>>A+</option>
                                                    <option value="A-" <?php if ($patient['blood_type'] == 'A-') echo 'selected'; ?>>A-</option>
                                                    <option value="B+" <?php if ($patient['blood_type'] == 'B+') echo 'selected'; ?>>B+</option>
                                                    <option value="B-" <?php if ($patient['blood_type'] == 'B-') echo 'selected'; ?>>B-</option>
                                                    <option value="AB+" <?php if ($patient['blood_type'] == 'AB+') echo 'selected'; ?>>AB+</option>
                                                    <option value="AB-" <?php if ($patient['blood_type'] == 'AB-') echo 'selected'; ?>>AB-</option>
                                                    <option value="O+" <?php if ($patient['blood_type'] == 'O+') echo 'selected'; ?>>O+</option>
                                                    <option value="O-" <?php if ($patient['blood_type'] == 'O-') echo 'selected'; ?>>O-</option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label for="organ_needed" class="form-label">Organ Needed</label>
                                                <select class="form-control" id="organ_needed" name="organ_needed" required>
                                                    <option value="Heart" <?php if ($patient['organ_needed'] == 'Heart') echo 'selected'; ?>>Heart</option>
                                                    <option value="Kidney" <?php if ($patient['organ_needed'] == 'Kidney') echo 'selected'; ?>>Kidney</option>
                                                    <option value="Liver" <?php if ($patient['organ_needed'] == 'Liver') echo 'selected'; ?>>Liver</option>
                                                    <option value="Lung" <?php if ($patient['organ_needed'] == 'Lung') echo 'selected'; ?>>Lung</option>
                                                    <option value="Pancreas" <?php if ($patient['organ_needed'] == 'Pancreas') echo 'selected'; ?>>Pancreas</option>
                                                    <option value="Intestine" <?php if ($patient['organ_needed'] == 'Intestine') echo 'selected'; ?>>Intestine</option>
                                                    <option value="Corneas" <?php if ($patient['organ_needed'] == 'Corneas') echo 'selected'; ?>>Corneas</option>
                                                </select>
                                            </div>
                                            <button type="submit" name="edit_patient" class="btn btn-primary">Save Changes</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        
                        <!-- Delete Patient Modal -->
                        <div class="modal fade" id="deletePatientModal<?php echo $patient['id']; ?>" tabindex="-1" aria-labelledby="deletePatientModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="deletePatientModalLabel">Delete Patient</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form method="post" action="manage_patients.php">
                                            <input type="hidden" name="id" value="<?php echo $patient['id']; ?>">
                                            <p>Are you sure you want to delete this patient?</p>
                                            <button type="submit" name="delete_patient" class="btn btn-danger">Delete</button>
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="col-md-4">
                <h5>Add New Patient</h5>
                <form method="post" action="manage_patients.php">
                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="age" class="form-label">Age</label>
                        <input type="number" class="form-control" id="age" name="age" required>
                    </div>
                   <div class="mb-3">
                        <label for="blood_type" class="form-label">Blood Type</label>
                        <select class="form-control" id="blood_type" name="blood_type" required>
                            <option value="A+">A+</option>
                            <option value="A-">A-</option>
                            <option value="B+">B+</option>
                            <option value="B-">B-</option>
                            <option value="AB+">AB+</option>
                            <option value="AB-">AB-</option>
                            <option value="O+">O+</option>
                            <option value="O-">O-</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="organ_needed" class="form-label">Organ Needed</label>
                        <input type="text" class="form-control" id="organ_needed" name="organ_needed" required>
                    </div>
                    <button type="submit" name="add_patient" class="btn btn-success">Add Patient</button>
                </form>
            </div>
        </div>
    </div>

  
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
