<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'project');

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Function to fetch data based on the module
function fetchData($conn, $module)
{
    if ($module === 'donor') {
        $query = "SELECT id, full_name, email, phone, blood_group, organs FROM donor";  // Adjust table name
        $columns = ['ID', 'Full Name', 'Email', 'Phone', 'Blood Group', 'Organs'];
    } elseif ($module === 'hospital') {
        $query = "SELECT id, name, address, phone, email FROM hospital";  // Adjust table name
        $columns = ['ID', 'Name', 'Address', 'Phone', 'Email'];
    } elseif ($module === 'volunteer') {
        $query = "SELECT id, full_name, email, phone, area_of_interest FROM volunteer";  // Adjust table name
        $columns = ['ID', 'Full Name', 'Email', 'Phone', 'Area of Interest'];
    } else {
        return "<p style='color: red;'>Invalid module selected.</p>";
    }

    $result = $conn->query($query);

    // Check if the query was successful
    if ($result === false) {
        return "<p style='color: red;'>Error executing query: " . $conn->error . "</p>";
    }

    $html = "<h1>" . ucfirst($module) . " Management</h1>";
    $html .= "<table>";
    $html .= "<thead><tr>";

    foreach ($columns as $column) {
        $html .= "<th>{$column}</th>";
    }

    $html .= "</tr></thead><tbody>";

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $html .= "<tr>";
            foreach ($row as $value) {
                $html .= "<td>{$value}</td>";
            }
            $html .= "</tr>";
        }
    } else {
        $html .= "<tr><td colspan='" . count($columns) . "'>No data found</td></tr>";
    }

    $html .= "</tbody></table>";
    return $html;
}


if (isset($_GET['module'])) {
    echo fetchData($conn, $_GET['module']);
    $conn->close();
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* General Styles */
        body {
            margin: 0;
            font-family: 'Roboto', sans-serif;
            background: white;
            color: black;
            display: flex;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background-color: #d3935c;
            color: white;
            height: 100vh;
            padding: 20px;
            position: fixed;
            transition: transform 0.3s ease-in-out;
        }

        .sidebar.closed {
            transform: translateX(-100%);
        }

        .sidebar h2 {
            text-align: center;
            font-size: 1.5rem;
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            margin: 15px 0;
        }

        .sidebar ul li a {
            text-decoration: none;
            color: white;
            font-size: 1rem;
            display: flex;
            align-items: center;
            padding: 10px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .sidebar ul li a:hover {
            background-color: black;
            color: white;
        }

        .sidebar ul li a i {
            margin-right: 10px;
        }

        /* Toggle Button Styles */
        .toggle-btn {
            position: fixed;
            top: 20px;
            left: 250px;
            background-color: #d3935c;
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            font-size: 1rem;
            transition: left 0.3s ease-in-out;
        }

        .toggle-btn.closed {
            left: 20px;
        }

        /* Main Content Styles */
        .main-content {
            margin-left: 250px;
            padding: 20px;
            width: calc(100% - 250px);
            transition: margin-left 0.3s ease-in-out;
        }

        .main-content.full-width {
            margin-left: 20px;
            width: calc(100% - 20px);
        }

        .main-content h1 {
            font-size: 2rem;
            margin-bottom: 20px;
            color: #d3935c;
        }

        /* Table Styles */
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        table th, table td {
            text-align: left;
            padding: 12px;
            border: 1px solid #ccc;
        }

        table th {
            background-color: #d3935c;
            color: white;
        }

        table tr:hover {
            background-color: #f7e5d4;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="#" data-module="donors"><i class="fas fa-hand-holding-heart"></i> Donor Management</a></li>
            <li><a href="#" data-module="hospitals"><i class="fas fa-hospital"></i> Hospital Management</a></li>
            <li><a href="#" data-module="volunteers"><i class="fas fa-hands-helping"></i> Volunteer Management</a></li>
        </ul>
    </div>

    <!-- Toggle Button -->
    <button class="toggle-btn" id="toggleBtn">
        <i class="fas fa-arrow-left"></i>
    </button>

    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <h1>Welcome to the Admin Dashboard</h1>
        <div id="contentSection">
            <!-- Dynamic content will load here -->
        </div>
    </div>

    <script>
        const sidebar = document.getElementById('sidebar');
        const toggleBtn = document.getElementById('toggleBtn');
        const mainContent = document.getElementById('mainContent');
        const contentSection = document.getElementById('contentSection');

        // Toggle Sidebar
        toggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('closed');
            toggleBtn.classList.toggle('closed');
            mainContent.classList.toggle('full-width');
        });

        // Fetch and display data dynamically
        document.querySelectorAll('.sidebar a[data-module]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const module = link.getAttribute('data-module');
                fetch(`?module=${module}`)
                    .then(response => response.text())
                    .then(data => {
                        contentSection.innerHTML = data;
                    })
                    .catch(error => {
                        console.error('Error fetching data:', error);
                        contentSection.innerHTML = `<p style="color: red;">Error loading ${module} data.</p>`;
                    });
            });
        });
    </script>
</body>
</html>

