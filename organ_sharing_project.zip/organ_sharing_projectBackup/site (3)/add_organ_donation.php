<?php
session_start();
include 'db_connection.php';

if (!isset($_SESSION['donor_id'])) {
    header("Location: donorlogin.php");
    exit();
}

$donor_id = $_SESSION['donor_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $organ = htmlspecialchars($_POST['organ']);
    $donation_date = htmlspecialchars($_POST['donation_date']);

    // Fetch existing organs and append new organ
    $stmt = $conn->prepare("SELECT organs, donation_date FROM donor WHERE id = ?");
    $stmt->bind_param("i", $donor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $existing_data = $result->fetch_assoc();

    $new_organs = $existing_data['organs'] ? $existing_data['organs'] . ',' . $organ : $organ;
    $new_donation_date = $existing_data['donation_date'] ? $existing_data['donation_date'] . ',' . $donation_date : $donation_date;

    $stmt->close();

    // Update donor record with new organ donation
    $stmt = $conn->prepare("UPDATE donor SET organs = ?, donation_date = ? WHERE id = ?");
    if (!$stmt) {
        throw new Exception("Prepare statement for updating donor record failed: " . $conn->error);
    }
    $stmt->bind_param("ssi", $new_organs, $new_donation_date, $donor_id);
    $stmt->execute();
    $stmt->close();

    header("Location: index.html");
    exit();
} else {
    echo "Invalid request method.";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Organ Donation Program</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h2>Organ Donation Program</h2>
        <form action="add_organ_donation.php" method="post">
            <div class="mb-3">
                <label for="organ" class="form-label">Organ</label>
                <input type="text" name="organ" id="organ" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="donation_date" class="form-label">Donation Date</label>
                <input type="date" name="donation_date" id="donation_date" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Add Donation</button>
        </form>

        <!-- Display Organs Donated -->
        <h3 class="mt-4">Organs Donated</h3>
        <table class="table">
            <thead>
                <tr>
                    <th>Organ</th>
                    <th>Donation Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include 'db_connection.php';

                $donor_id = $_SESSION['donor_id'];
                $stmt = $conn->prepare("SELECT organs, donation_date FROM donor WHERE id = ?");
                $stmt->bind_param("i", $donor_id);
                $stmt->execute();
                $result = $stmt->get_result();

                while ($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . htmlspecialchars($row['organs']) . "</td><td>" . htmlspecialchars($row['donation_date']) . "</td></tr>";
                }

                if ($result->num_rows == 0) {
                    echo "<tr><td colspan='2' class='text-center'>No organs donated</td></tr>";
                }

                $stmt->close();
                ?>
            </tbody>
        </table>
    </div>

    <script>
        function confirmLogout() {
            if (confirm("Are you sure you want to logout?")) {
                window.location.href = "logout.php";
            }
        }
    </script>
</body>
</html>
