<?php
session_start();
include 'db_connection.php';

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Update status if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['complete_transplant'])) {
    $transplant_id = $_POST['transplant_id'];
    $sql = "UPDATE transplant_schedule SET status = 'completed' WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $transplant_id);
    if ($stmt->execute()) {
        $_SESSION['success'] = "Transplant status updated to completed.";
    } else {
        $_SESSION['error'] = "Error updating transplant status: " . $stmt->error;
    }
    $stmt->close();
    header("Location: transplant_status.php");
    exit();
}

// Fetch scheduled transplants
$sql = "SELECT ts.id, ts.patient_id, ts.donor_id, ts.transplant_date, ts.status, p.name AS patient_name, d.full_name AS donor_name, om.organ_type
        FROM transplant_schedule ts
        JOIN patients p ON ts.patient_id = p.id
        JOIN donor d ON ts.donor_id = d.id
        JOIN organ_matching om ON ts.patient_id = om.patient_id AND ts.donor_id = om.donor_id
        WHERE ts.status = 'scheduled'";
$result = $conn->query($sql);

// Check if the query was successful
if ($result === false) {
    die("Error executing query: " . $conn->error);
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Scheduled Transplants</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <a class="navbar-brand" href="dashboard.php">Hospital Dashboard</a>
        <a href="hospitaldashboard.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </nav>

    <div class="container mt-4">
        <h1>Scheduled Transplants</h1>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Patient Name</th>
                    <th>Donor Name</th>
                    <th>Organ</th>
                    <th>Scheduled Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["id"] . "</td>";
                        echo "<td>" . $row["patient_name"] . "</td>";
                        echo "<td>" . $row["donor_name"] . "</td>";
                        echo "<td>" . $row["organ_type"] . "</td>";
                        echo "<td>" . $row["transplant_date"] . "</td>";
                        echo "<td>" . $row["status"] . "</td>";
                        echo "<td>";
                        if ($row["status"] == 'scheduled') {
                            echo "<form method='post' action='transplant_status.php'>";
                            echo "<input type='hidden' name='transplant_id' value='" . $row["id"] . "'>";
                            echo "<button type='submit' name='complete_transplant' class='btn btn-success'>Mark as Completed</button>";
                            echo "</form>";
                        }
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No scheduled transplants found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
<?php
$conn->close();
?>

