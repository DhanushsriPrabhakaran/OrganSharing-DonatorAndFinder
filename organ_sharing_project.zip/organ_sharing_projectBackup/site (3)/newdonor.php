<?php
// Database connection
$servername = "localhost";
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "project"; // Your database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST['name'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $blood = $_POST['blood'];
    $organs = implode(", ", $_POST['organs']); // Preferred Organs for Donation
    $emergency_contact_name = $_POST['emergency_contact_name'];
    $emergency_contact_phone = $_POST['emergency_contact_phone'];
    $consent = isset($_POST['consent']) ? 1 : 0; // Consent checkbox
    $password = $_POST['password']; // Get password from the form

    // Hash the password before storing it in the database
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert form data into the database
    $sql = "INSERT INTO donor (full_name, dob, gender, phone, email, address, blood_group, organs, emergency_contact_name, emergency_contact_phone, consent, password)
            VALUES ('$name', '$dob', '$gender', '$phone', '$email', '$address', '$blood', '$organs', '$emergency_contact_name', '$emergency_contact_phone', '$consent', '$hashed_password')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Donor registration successful!'); window.location.href = 'donorlogin.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Donor Registration</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f9f9f9;
      background-image: url('tem4.jpeg');
      background-repeat: no-repeat;
      background-attachment: fixed;
      background-size: cover;
    }

    header {
      background-color: #333;
      color: #fff;
      padding: 10px 20px;
      margin-bottom: 20px;
    }
    header h1 {
      margin: 0;
      font-size: 1.5rem;
    }
    header nav a {
      color: #fff;
      text-decoration: none;
      margin-right: 15px;
    }
    header nav a:last-child {
      margin-right: 0;
    }
    .container {
      max-width: 800px;
      margin: 50px auto;
      background: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .form-title {
      text-align: center;
      margin-bottom: 20px;
    }
    .form-title h2 {
      font-size: 24px;
      color: #333;
    }
    .form-title span {
      color: #e74c3c;
    }
    form {
      display: grid;
      gap: 20px;
    }
    label {
      font-size: 14px;
      color: black;
    }
    input, select, textarea {
      width: 100%;
      padding: 10px;
      font-size: 14px;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
    }
    .form-row {
      display: flex;
      gap: 20px;
    }
    .form-row > div {
      flex: 1;
    }
    .checkbox-group, .radio-group {
      display: flex;
      gap: 10px;
      align-items: center;
      flex-wrap: wrap;
    }
    .submit-btn {
      background-color: #D3935C;
      color: #fff;
      border: none;
      padding: 12px 0; /* Adjust padding to make the button longer */
      font-size: 16px;
      cursor: pointer;
      border-radius: 5px;
      width: 100%; /* Set the width to 100% to make it the same length as the form */
      transition: 0.3s;

    }
    .submit-btn:hover {
      background-color: #c0392b;
    }
    .password-strength {
      margin-top: 10px;
      font-size: 14px;
      font-weight: bold;
    }
    .login-link {
      text-align: center;
      margin-top: 20px;
    }

    .login-link a {
      text-decoration: none;
      color: black;
      font-weight: bold;
      font-size: 1em;
      transition: color 0.3s ease-in-out;
    }

    .login-link a:hover {
      color: #d3935c;
    }
    p {
            text-align: center;
            color: #555;
        }
  </style>
</head>
<body>
  <header>
    <div style="display: flex; justify-content: space-between; align-items: center;">
      <h1>ORGAN SHARING</h1>
      <nav>
         <a href="log.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Login</a>
      </nav>
    </div>
  </header>

  <div style="text-align: center; margin-bottom: 20px;">
    <img src="or1.png" alt="Organ Donation Initiative" style="max-width: 12%; height: auto; border-radius: 8px;">
  </div>

  <div class="container">
    <div class="form-title">
      <h4>YOUR LEGACY CAN LIVE ON - DONATE YOUR ORGANS</h4>
      <h2>Become a <span>Donor</span></h2>
    </div>
    <form action="" method="POST">
      <div class="form-row">
        <div>
          <label for="name"><strong>Full Name *</strong></label>
          <input type="text" id="name" name="name" required>
        </div>
        <div>
          <label for="dob"><strong>Date of Birth</strong></label>
          <input type="date" id="dob" name="dob">
        </div>
      </div>
      <div class="form-row">
        <div>
          <label for="gender"><strong>Gender *</strong></label>
          <select id="gender" name="gender" required>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
        </div>
        <div>
          <label for="phone"><strong>Phone No. *</strong></label>
          <input type="tel" id="phone" name="phone" required>
        </div>
      </div>
      <div>
        <label for="email"><strong>E-mail</strong></label>
        <input type="email" id="email" name="email">
      </div>
      <div>
        <label for="address"><strong>Address *</strong></label>
        <textarea id="address" name="address" rows="2" required></textarea>
      </div>
      <div class="form-row">
        <div>
          <label for="blood"><strong>Blood Group</strong></label>
          <select id="blood" name="blood">
            <option value="" disabled selected>Select</option>
            <option value="A+">A+</option>
            <option value="B+">B+</option>
            <option value="O+">O+</option>
            <option value="AB+">AB+</option>
            <option value="A-">A-</option>
            <option value="B-">B-</option>
            <option value="O-">O-</option>
            <option value="AB-">AB-</option>
          </select>
        </div>
      </div>
      <div>
        <label><strong>Preferred Organs for Donation</strong></label>
        <div class="checkbox-group">
          <label><input type="checkbox" name="organs[]" value="Heart"> Heart</label>
          <label><input type="checkbox" name="organs[]" value="Kidney"> Kidney</label>
          <label><input type="checkbox" name="organs[]" value="Liver"> Liver</label>
          <label><input type="checkbox" name="organs[]" value="Lungs"> Lungs</label>
          <label><input type="checkbox" name="organs[]" value="Corneas"> Corneas</label>
          <label><input type="checkbox" name="organs[]" value="Pancreas"> Pancreas</label>
        </div>
      </div> <p><strong>If for some reason you were not able to make a decision towards donating or undergoing surgery, you may have an emergency contact to make the decision for you. If you would like to give someone this right, fill out their information below</strong></p>

      <div>
        <label for="emergency_contact_name"><strong>Emergency Contact Name *</strong></label>
        <input type="text" id="emergency_contact_name" name="emergency_contact_name" required>
      </div>
      <div>
        <label for="emergency_contact_phone"><strong>Emergency Contact Phone *</strong></label>
        <input type="tel" id="emergency_contact_phone" name="emergency_contact_phone" required>
      </div>
<div>
        <label for="password"><strong>Password *</strong></label>
        <input type="password" id="password" name="password" required>
      </div>


      <div class="checkbox-group">
        <label><strong><input type="checkbox" name="consent" required> I consent to donate my organs<strong></label>
      </div>
      <p>Note: The information you are entering in the above form is confidential and will be used only for the purpose of organ donation and transplant processes and will not be shared/used for any other purpose.</p><br>

     
      <button type="submit" class="submit-btn">Register</button>
    </form>
    <div class="login-link">
      <p>Already a donor? <a href="donorlogin.php">Login here</a></p>
    </div>
  </div>
</body>
</html>
