<?php
session_start();
include 'db_connection.php'; // Ensure this path is correct

$success_message = "";

// Handle organ request submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['request_organ'])) {
    $requested_organ = $_POST['organ'];
    $hospital_name = $_SESSION['hospital_name']; // Assuming hospital name is stored in session
    $urgency = $_POST['urgency']; // Allow urgency input in the form
    $status = 'Pending'; // Initial status for new requests

    try {
        $stmt = $conn->prepare("INSERT INTO organ_requests (hospital_name, organ_requested, urgency, status) VALUES (?, ?, ?, ?)");
        if ($stmt === false) {
            die("Prepare failed: " . $conn->error);
        }
        $stmt->bind_param("ssss", $hospital_name, $requested_organ, $urgency, $status);
        $stmt->execute();
        $success_message = "Organ request submitted successfully.";
        $stmt->close();
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
        exit();
    }
}

// Fetch donor details
$search = '';
if (isset($_GET['search'])) {
    $search = $_GET['search'];
}
try {
    $stmt = $conn->prepare("SELECT * FROM donor WHERE full_name LIKE ? OR email LIKE ? OR address LIKE ? OR blood_group LIKE ? OR organs LIKE ?");
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }
    $search_param = '%' . $search . '%';
    $stmt->bind_param("sssss", $search_param, $search_param, $search_param, $search_param, $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Donors</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        .table thead th {
            background-color: #000;
            color: #fff;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-dark bg-dark p-3">
    <a class="navbar-brand" href="hospitaldashboard.php">Hospital Dashboard</a>
    <a href="hospitaldashboard.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to dashboard</a>
</nav>
<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <h3>Donor List</h3>
            <div class="card mt-4">
                <div class="card-body">
                    <?php if (!empty($success_message)): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo htmlspecialchars($success_message); ?>
                        </div>
                    <?php endif; ?>
                    <form method="get" class="d-flex mb-3">
                        <input type="text" name="search" class="form-control me-2" placeholder="Search by any field" value="<?php echo htmlspecialchars($search); ?>">
                        <button type="submit" class="btn btn-primary me-2">Search</button>
                        <a href="view_donors.php" class="btn btn-secondary">Remove Filters</a>
                    </form>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Full Name</th>
                                    <th>Date of Birth</th>
                                    <th>Gender</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th>Address</th>
                                    <th>Blood Group</th>
                                    <th>Organs</th>
                                    <th>Request Organ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['id']); ?></td>
                                        <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['dob']); ?></td>
                                        <td><?php echo htmlspecialchars($row['gender']); ?></td>
                                        <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                                        <td><?php echo htmlspecialchars($row['address']); ?></td>
                                        <td><?php echo htmlspecialchars($row['blood_group']); ?></td>
                                        <td><?php echo htmlspecialchars($row['organs']); ?></td>
                                        <td>
                                            <form method="post" class="d-flex">
                                                <select name="organ" class="form-select me-2">
                                                    <?php 
                                                    $organs = explode(',', $row['organs']);
                                                    foreach ($organs as $organ) {
                                                        echo "<option value=\"" . htmlspecialchars($organ) . "\">" . htmlspecialchars($organ) . "</option>";
                                                    }
                                                    ?>
                                                </select>
                                                <input type="text" name="urgency" class="form-control me-2" placeholder="Enter urgency">
                                                <button type="submit" name="request_organ" class="btn btn-primary">Request</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p>No donors found.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
