<?php
include 'db_connection.php';

try {
    // Fetch participants from the participation table
    $participants = [];
    $query = "SELECT volunteer_name, event_name, email, phone_number FROM participation ORDER BY event_name, volunteer_name";
    $result = $conn->query($query);

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $participants[] = $row;
        }
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Participants</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <a class="navbar-brand" href="admin_dashboard.php">Admin Dashboard</a>
        <a href="d1.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </nav>

    <div class="container mt-4">
        <h3>Event Participants</h3>
        <?php if (empty($participants)): ?>
            <div class="alert alert-warning">No participants enrolled yet.</div>
        <?php else: ?>
            <table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>Volunteer Name</th>
                        <th>Event Name</th>
                        <th>Email</th>
                        <th>Phone Number</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($participants as $participant): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($participant['volunteer_name']); ?></td>
                            <td><?php echo htmlspecialchars($participant['event_name']); ?></td>
                            <td><?php echo htmlspecialchars($participant['email']); ?></td>
                            <td><?php echo htmlspecialchars($participant['phone_number']); ?></td>
                            <td>
                                <a href="mailto:<?php echo htmlspecialchars($participant['email']); ?>" class="btn btn-primary btn-sm"><i class="fas fa-envelope"></i> Email</a>
                                                          </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
            </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
