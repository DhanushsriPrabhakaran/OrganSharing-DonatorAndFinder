<?php
session_start();
include 'db_connection.php';
require_once 'libs/fpdf.php'; 
require_once 'libs/phpqrcode/qrlib.php'; 

if (!isset($_SESSION['donor_id'])) {
    header("Location: donorlogin.php");
    exit();
}

try {
    $donor_id = $_SESSION['donor_id'];
    $stmt = $conn->prepare("SELECT * FROM donor WHERE id = ?");
    $stmt->bind_param("i", $donor_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $row = $result->fetch_assoc()) {
        $donor_profile = $row;
    } else {
        throw new Exception("Donor profile not found.");
    }

    // Ensure QR Code directory exists
    $qrDir = 'qrcodes/';
    if (!is_dir($qrDir)) {
        mkdir($qrDir, 0777, true);
    }

    // Generate QR Code with donor details
    $qrData = "Name: " . htmlspecialchars($donor_profile['full_name']) . "\n";
    $qrData .= "Date of Birth: " . htmlspecialchars($donor_profile['dob']) . "\n";
    $qrData .= "Gender: " . htmlspecialchars($donor_profile['gender']) . "\n";
    $qrData .= "Email: " . htmlspecialchars($donor_profile['email']) . "\n";
    $qrData .= "Phone: " . htmlspecialchars($donor_profile['phone']) . "\n";
    $qrData .= "Blood Group: " . htmlspecialchars($donor_profile['blood_group']) . "\n";
    $qrData .= "Address: " . htmlspecialchars($donor_profile['address']) . "\n";

    $qrFilePath = $qrDir . 'donor_' . $donor_id . '.png';
    QRcode::png($qrData, $qrFilePath, QR_ECLEVEL_L, 4);

    // PDF Class for Donor ID Card
    class PDF extends FPDF {
        function Header() {
            $this->SetFont('Arial', 'B', 15);
            $this->Cell(0, 10, 'Organ Sharing - Donor ID Card', 0, 1, 'C');
            $this->Ln(5);
        }

        function Footer() {
            $this->SetY(-15);
            $this->SetFont('Arial', 'I', 8);
            $this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'C');
        }

        function DonorCard($name, $dob, $gender, $email, $phone, $blood_group, $address, $qrPath) {
            $this->SetFont('Arial', '', 12);
            $this->Ln(10);
            $this->Cell(0, 10, "Name: $name", 0, 1, 'C');
            $this->Cell(0, 10, "Date of Birth: $dob", 0, 1, 'C');
            $this->Cell(0, 10, "Gender: $gender", 0, 1, 'C');
            $this->Cell(0, 10, "Email: $email", 0, 1, 'C');
            $this->Cell(0, 10, "Phone: $phone", 0, 1, 'C');
            $this->Cell(0, 10, "Blood Group: $blood_group", 0, 1, 'C');
            $this->Cell(0, 10, "Address: $address", 0, 1, 'C');

            // QR Code
            $this->Ln(10);
            if (file_exists($qrPath)) {
                $this->Image($qrPath, 75, 120, 50, 50); // Positioning the QR code
            } else {
                $this->Cell(0, 10, "QR Code Not Available", 0, 1, 'C');
            }
        }
    }

    // Generate PDF
    $pdf = new PDF();
    $pdf->AddPage();
    $pdf->DonorCard(
        htmlspecialchars($donor_profile['full_name']),
        htmlspecialchars($donor_profile['dob']),
        htmlspecialchars($donor_profile['gender']),
        htmlspecialchars($donor_profile['email']),
        htmlspecialchars($donor_profile['phone']),
        htmlspecialchars($donor_profile['blood_group']),
        htmlspecialchars($donor_profile['address']),
        $qrFilePath
    );
    $pdf->Output('D', 'Donor_ID_Card.pdf');
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>
