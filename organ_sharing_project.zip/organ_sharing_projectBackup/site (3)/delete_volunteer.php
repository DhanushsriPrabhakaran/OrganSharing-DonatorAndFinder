<?php
session_start();
include 'db_connection.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    try {
        $stmt = $conn->prepare("DELETE FROM volunteer WHERE id = ?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            $_SESSION['success'] = "Volunteer deleted successfully!";
        } else {
            $_SESSION['error'] = "Failed to delete volunteer.";
        }

        $stmt->close();
    } catch (Exception $e) {
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }
} else {
    $_SESSION['error'] = "Invalid request!";
}

header("Location: managevolunteer.php");
exit();
?>
