<?php
session_start();
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $donor_id = $_POST['donor_id'];
    $hospital_id = $_POST['hospital_id'];
    $organ_type = $_POST['organ_type'];
    $status = 'pending'; // Set the initial status to pending

    try {
        $stmt = $conn->prepare("INSERT INTO donation_requests (donor_id, hospital_id, organ_type, status) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiss", $donor_id, $hospital_id, $organ_type, $status);

        if ($stmt->execute()) {
            $_SESSION['success'] = "Donation request added successfully!";
        } else {
            $_SESSION['error'] = "Failed to add donation request.";
        }

        $stmt->close();
    } catch (Exception $e) {
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }

    // Redirect to manage_donation_requests.php after adding the request
    header("Location: manage_donation_requests.php");
    exit();
}
?>
