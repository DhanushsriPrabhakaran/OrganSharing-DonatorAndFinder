<?php
session_start();
include 'db_connection.php';

if (!isset($_SESSION['volunteer_id'])) {
    header("Location: volunteerlogin.php");
    exit();
}

$success_message = "";
$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Update volunteer profile details
    $volunteer_id = $_SESSION['volunteer_id'];
    $full_name = $_POST['full_name'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $blood_group = $_POST['blood_group'];
    $gender = $_POST['gender'];
    $time_of_contribution = $_POST['time_of_contribution'];
    $area_of_interest = $_POST['area_of_interest'];

    $stmt = $conn->prepare("UPDATE volunteer SET full_name=?, dob=?, email=?, address=?, phone=?, blood_group=?, gender=?, time_of_contribution=?, area_of_interest=? WHERE id=?");
    $stmt->bind_param("sssssssssi", $full_name, $dob, $email, $address, $phone, $blood_group, $gender, $time_of_contribution, $area_of_interest, $volunteer_id);

    if ($stmt->execute()) {
        $success_message = "Profile updated successfully!";
    } else {
        $error_message = "Error updating profile: " . $stmt->error;
    }

    $stmt->close();
}

// Fetch volunteer profile details
$volunteer_id = $_SESSION['volunteer_id'];
$volunteer_profile = [];
$result = $conn->query("SELECT * FROM volunteer WHERE id = $volunteer_id");
if ($result && $row = $result->fetch_assoc()) {
    $volunteer_profile = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Volunteer Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-dark bg-dark p-3">
        <a class="navbar-brand" href="volunteer_dashboard.php">Volunteer Dashboard</a>
        <a href="volunteerdashboard.php" class="btn btn-secondary" ><i class="fas fa-arrow-left"></i> Back to dashboard</a>
    </nav>
    
    <div class="container mt-4">
        <div class="row">
            
            <div class="col-md-9">
                <h2>Update Profile</h2>

                <?php if (!empty($success_message)) { echo "<div class='alert alert-success'>$success_message</div>"; } ?>
                <?php if (!empty($error_message)) { echo "<div class='alert alert-danger'>$error_message</div>"; } ?>

                <form method="POST" action="update_volunteer_profile.php">
                    <div class="mb-3">
                        <label for="full_name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo htmlspecialchars($volunteer_profile['full_name']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="dob" class="form-label">Date of Birth</label>
                        <input type="date" class="form-control" id="dob" name="dob" value="<?php echo htmlspecialchars($volunteer_profile['dob']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($volunteer_profile['email']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="address" class="form-label">Address</label>
                        <textarea class="form-control" id="address" name="address" required><?php echo htmlspecialchars($volunteer_profile['address']); ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="form-label">Phone</label>
                        <input type="text" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($volunteer_profile['phone']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="blood_group" class="form-label">Blood Group</label>
                        <input type="text" class="form-control" id="blood_group" name="blood_group" value="<?php echo htmlspecialchars($volunteer_profile['blood_group']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="gender" class="form-label">Gender</label>
                        <input type="text" class="form-control" id="gender" name="gender" value="<?php echo htmlspecialchars($volunteer_profile['gender']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="time_of_contribution" class="form-label">Time of Contribution</label>
                        <input type="text" class="form-control" id="time_of_contribution" name="time_of_contribution" value="<?php echo htmlspecialchars($volunteer_profile['time_of_contribution']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="area_of_interest" class="form-label">Area of Interest</label>
                        <textarea class="form-control" id="area_of_interest" name="area_of_interest" required><?php echo htmlspecialchars($volunteer_profile['area_of_interest']); ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Update Profile</button>
                </form>

            </div>
        </div>
    </div>

    </body>
</html>
